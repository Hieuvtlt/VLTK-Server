-- Bo ky nang That Truyen - trao skill qua su phu mon phai
-- Dat tai: \script\global\thattruyen_head.lua
-- Chi trao skill chinh (tang 1). Cac tang con do engine tu goi qua event chain.
--
-- Luong chay:
--   tt_learn()    -> hien BANG DIEU KIEN (chi doc), co nut xac nhan neu du dieu kien
--   tt_do_learn() -> kiem tra lai TOAN BO roi moi tru hoc phi va trao skill

TT_LEVEL_REQUIRE   = 110	-- cap do toi thieu
TT_SKILL_LEVEL     = 1		-- cap khoi diem cua skill That Truyen sau khi hoc
TT_ORIGIN_MAXLEVEL = 20		-- skill goc phai dat cap nay (MaxLevel goc deu = 20)

TT_TONGKIM_POINT = 15000	-- diem tich luy Tong Kim can co (GetTask 751)
TT_DATAU_COUNT   = 40		-- so nhiem vu Da Tau hoan thanh LIEN TUC trong ngay
TT_COST_TIENDONG = 50		-- hoc phi: tien dong
TT_COST_CASH     = 1000000	-- hoc phi: luong (100 van)

-- Task ID cua he thong co san (da doi chieu ma nguon server)
TT_TASKID_TONGKIM = 751		-- diem tich luy Tong Kim (BT_SetType2Task(1, 751))
TT_TASKID_DATAU   = 2064	-- DAILY_STREAK_TASKID trong seasonnpc.lua

-- Tien Dong la vat pham xep chong {4, 417, 1} trong TUI.
-- Dem bang CalcItemCount(3,...) va tru bang ConsumeItem(3,...) - mau lay tu
-- recoin_goldenequip.lua (code that dang chay voi CHINH item nay).
-- KHONG dung GetItemCountEx/ConsumeEquiproomItem: khong nhin thay tien dong trong tui.
TT_ITEM_TIENDONG_D = 417

-- index = GetLastFactionNumber()
-- moi dong: {SkillId That Truyen, SkillId goc phai max, ten goc de hien thi}
TT_SKILL_LIST =
{
	[0] = {	-- Thieu Lam
		{1245, 318, "��t Ma �� Giang"},
		{1256, 319, "Ho�nh T�o Thi�n Qu�n"},
		{1255, 321, "V� T��ng Tr�m"},
	},
	[1] = {	-- Thien Vuong
		{1275, 322, "Ph� Thi�n Tr�m"},
		{1273, 325, "Truy Phong Quy�t"},
		{1271, 323, "Truy Tinh Tr�c Nguy�t"},
	},
	[2] = {	-- Duong Mon
		{1251, 302, "B�o V� L� Hoa"},
		{1253, 342, "C�u Cung Phi Tinh"},
		{1248, 339, "Nhi�p H�n Nguy�t �nh"},
	},
	[3] = {	-- Ngu Doc
		{1257, 355, "Huy�n �m Tr�m"},
		{1260, 353, "�m Phong Th�c C�t"},
	},
	[4] = {	-- Nga Mi
		{1227, 380, "Phong S��ng To�i �nh"},
		{1230, 328, "Tam Nga T� Tuy�t"},
	},
	[5] = {	-- Thuy Yen
		{1233, 336, "B�ng Tung V� �nh"},
		{1235, 337, "B�ng T�m Ti�n T�"},
	},
	[6] = {	-- Cai Bang
		{1237, 357, "Phi Long T�i Thi�n"},
		{1238, 359, "Thi�n H� V� C�u"},
	},
	[7] = {	-- Thien Nhan
		{1224, 362, "Thi�n Ngo�i L�u Tinh"},
		{1226, 361, "V�n Long K�ch"},
	},
	[8] = {	-- Vo Dang
		{1218, 365, "Thi�n ��a V� C�c"},
		{1221, 368, "Nh�n Ki�m H�p Nh�t"},
	},
	[9] = {	-- Con Lon
		{1262, 375, "L�i ��ng C�u Thi�n"},
		{1266, 372, "Ng�o Tuy�t Ti�u Phong"},
	},
}

-- Mot dong trong bang dieu kien.
-- Dau tick CO MAU: xanh = da dat, do = chua dat.
-- `Say` cat cut chuoi qua dai nen phai giu duoi ~585 byte; moi cap the mau ton
-- ~20 byte. Bang hien chi ~6 dong (~330 byte) nen con du cho. Neu sau nay bang
-- dai them ma bi cut duoi thi bo bot the mau la cach tiet kiem hieu qua nhat.
function tt_line(bOk, szLabel, szValue, szIndent)
	local szMark = "<color=red>[ ]<color>"
	if (bOk == 1) then szMark = "<color=green>[v]<color>" end
	if (szIndent == nil) then szIndent = "" end
	return "<enter>"..szIndent..szMark.." "..szLabel..": "..szValue
end

-- Doc trang thai hien tai cua nguoi choi
function tt_get_state()
	local t = {}
	t.faction  = GetLastFactionNumber()
	t.level    = GetLevel()
	t.tongkim  = tonumber(GetTask(TT_TASKID_TONGKIM)) or 0
	t.datau    = tonumber(GetTask(TT_TASKID_DATAU)) or 0
	t.tiendong = CalcItemCount(3, 4, TT_ITEM_TIENDONG_D, 1, -1)
	t.cash     = GetCash()
	return t
end

-- Dem trang thai tuyet ky ban mon.
-- Tra ve: so mon da san sang (goc max hoac da hoc TT), so mon da hoc TT,
--         so mon hoc duoc ngay bay gio
function tt_count_origin(tList)
	local nReady, nLearned, nCanLearn = 0, 0, 0
	for i = 1, getn(tList) do
		if (HaveMagic(tList[i][1]) ~= -1) then
			nLearned = nLearned + 1
			nReady   = nReady + 1
		elseif (HaveMagic(tList[i][2]) >= TT_ORIGIN_MAXLEVEL) then
			nReady    = nReady + 1
			nCanLearn = nCanLearn + 1
		end
	end
	return nReady, nLearned, nCanLearn
end

-- BANG DIEU KIEN
-- Giu that NGAN: khung hoi thoai `Say` co chieu cao han che, bang dai se day
-- phan lua chon ra ngoai khung va che mat nut bam. Chi tiet tuyet ky ban mon
-- tach sang man rieng `tt_detail`.
function tt_learn()

	local t = tt_get_state()

	if (t.faction < 0) or (t.faction > 9) then
		Say("Ng��i ch�a gia nh�p m�n ph�i, ta kh�ng th� truy�n th� ���c.", 0)
		return
	end

	local tList = TT_SKILL_LIST[t.faction]
	local nTotal = getn(tList)
	local nReady, nLearned, nCanLearn = tt_count_origin(tList)

	local bGate = 1

	-- 1. Cap do - dong DAU TIEN nen khong co <enter>, tranh mot dong trong thua
	local szMark = "<color=red>[ ]<color>"
	if (t.level >= TT_LEVEL_REQUIRE) then szMark = "<color=green>[v]<color>" else bGate = 0 end
	local szText = szMark.." C�p ��: "..t.level.."/"..TT_LEVEL_REQUIRE
	local bOk = 0

	-- 2. Diem tich luy Tong Kim
	bOk = 0
	if (t.tongkim >= TT_TONGKIM_POINT) then bOk = 1 else bGate = 0 end
	szText = szText..tt_line(bOk, "�i�m T�ng Kim", t.tongkim.."/"..TT_TONGKIM_POINT)

	-- 3. Da Tau lien tuc trong ngay
	bOk = 0
	if (t.datau >= TT_DATAU_COUNT) then bOk = 1 else bGate = 0 end
	szText = szText..tt_line(bOk, "D� T�u h�m nay", t.datau.."/"..TT_DATAU_COUNT)

	-- 4. Tuyet ky ban mon - chi hien tong ket 1 dong
	-- Tick xanh khi CO IT NHAT 1 mon hoc duoc ngay, vi co che 1-1 cho hoc tung phan.
	-- Neu chi tick khi du 3/3 thi nguoi choi tuong minh chua dat dieu kien.
	bOk = 0
	if (nReady >= nTotal) or (nCanLearn > 0) then bOk = 1 end
	szText = szText..tt_line(bOk, "Tuy�t k� b�n m�n", nReady.."/"..nTotal.." luy�n th�nh")

	local bDone = 0
	if (nLearned >= nTotal) then bDone = 1 end

	-- 5. Hoc phi - gop 1 dong
	local bMoney = 1
	if (bDone == 1) then
		szText = szText..tt_line(1, "L� ph�", "�� tr� xong")
	else
		if (t.tiendong < TT_COST_TIENDONG) then bMoney = 0 end
		if (t.cash < TT_COST_CASH) then bMoney = 0 end
		szText = szText..tt_line(bMoney, "L� ph�",
			t.tiendong.."/"..TT_COST_TIENDONG.." T�, "
			..floor(t.cash/10000).."/"..floor(TT_COST_CASH/10000).." v�n")
	end

	if (bDone == 1) then
		Say(szText.."<enter><color=green>�� l�nh h�i tr�n v�n c� b�.<color>",
			2, "Xem tuy�t k� b�n m�n/tt_detail", "K�t th�c ��i tho�i/tt_quit")
		return
	end

	-- Cho hoc khi: qua 3 dieu kien chung + du le phi + co it nhat 1 mon san sang.
	-- Khong doi max HET tuyet ky ban mon, vi co che 1-1 cho phep hoc tung phan.
	if (bGate == 1) and (bMoney == 1) and (nCanLearn > 0) then
		-- Le phi thu theo MOI LUOT hoc, khong theo tung mon. Con mon chua mo khoa
		-- thi bao de nguoi choi biet cho luyen xong roi hoc gop cho re.
		local szNote = ""
		if (nCanLearn < (nTotal - nLearned)) then
			szNote = " Luy�n n�t r�i h�c g�p s� r� h�n."
		end
		Say(szText.."<enter><color=green>�� duy�n ph�n, c� th� l�nh h�i "..nCanLearn.." m�n."
			..szNote.."<color>",
			3, "Xin s� ph� truy�n th�/tt_do_learn",
			   "Xem tuy�t k� b�n m�n/tt_detail",
			   "�� ta chu�n b� th�m/tt_quit")
	else
		Say(szText.."<enter><color=red>C�n thi�u �i�u ki�n, ch�a th� truy�n th�.<color>",
			2, "Xem tuy�t k� b�n m�n/tt_detail", "K�t th�c ��i tho�i/tt_quit")
	end

end

-- MAN CHI TIET: tung tuyet ky ban mon va cap hien tai
function tt_detail()

	local t = tt_get_state()
	if (t.faction < 0) or (t.faction > 9) then
		Say("Ng��i ch�a gia nh�p m�n ph�i.", 0)
		return
	end

	local tList = TT_SKILL_LIST[t.faction]
	local szText = "Tuy�t k� b�n m�n ph�i luy�n ��n c�p "..TT_ORIGIN_MAXLEVEL..":"

	for i = 1, getn(tList) do
		if (HaveMagic(tList[i][1]) ~= -1) then
			szText = szText..tt_line(1, tList[i][3], "�� h�c")
		else
			local nLv = HaveMagic(tList[i][2])
			if (nLv < 0) then nLv = 0 end
			local bOk = 0
			if (nLv >= TT_ORIGIN_MAXLEVEL) then bOk = 1 end
			szText = szText..tt_line(bOk, tList[i][3], nLv.."/"..TT_ORIGIN_MAXLEVEL)
		end
	end

	Say(szText, 2, "Tr� l�i/tt_learn", "K�t th�c ��i tho�i/tt_quit")

end

function tt_quit()
end

-- HOC THAT SU - kiem tra lai toan bo, khong tin ket qua man hinh truoc
function tt_do_learn()

	local t = tt_get_state()

	if (t.faction < 0) or (t.faction > 9) then
		Say("Ng��i ch�a gia nh�p m�n ph�i, ta kh�ng th� truy�n th� ���c.", 0)
		return
	end

	if (t.level < TT_LEVEL_REQUIRE) then
		Say("C�n c� c�a ng��i c�n non. H�y quay l�i khi �� ��t c�p "..TT_LEVEL_REQUIRE..".", 0)
		return
	end

	if (t.tongkim < TT_TONGKIM_POINT) then
		Say("Ch�a t�ng v�o sinh ra t� n�i chi�n tr�n th� l�nh h�i sao ���c."
			.."<enter>�i�m t�ch l�y T�ng Kim: <color=yellow>"..t.tongkim.."/"..TT_TONGKIM_POINT.."<color>", 0)
		return
	end

	if (t.datau < TT_DATAU_COUNT) then
		Say("R�n luy�n ch�a ��. H�y �i l�m vi�c cho D� T�u th�m ��."
			.."<enter>D� T�u ho�n th�nh li�n t�c h�m nay: <color=yellow>"..t.datau.."/"..TT_DATAU_COUNT.."<color>"
			.."<enter><color=red>L�u �: h�y nhi�m v� gi�a ch�ng s� m�t h�t s� ��m.<color>", 0)
		return
	end

	-- Duyet tung cap: chi hoc duoc khi skill goc da max
	local tList = TT_SKILL_LIST[t.faction]
	local tCanLearn = {}
	local nAlreadyHave = 0

	for i = 1, getn(tList) do
		if (HaveMagic(tList[i][1]) ~= -1) then
			nAlreadyHave = nAlreadyHave + 1
		else
			if (HaveMagic(tList[i][2]) >= TT_ORIGIN_MAXLEVEL) then
				tinsert(tCanLearn, tList[i][1])
			end
		end
	end

	if (getn(tCanLearn) == 0) then
		if (nAlreadyHave >= getn(tList)) then
			Say("Ng��i �� l�nh h�i tr�n v�n b� v� h�c th�t truy�n c�a b�n m�n r�i.", 0)
		else
			Say("Tuy�t k� b�n m�n ch�a luy�n th�nh, kh�ng th� k� th�a v� h�c th�t truy�n.",
				1, "Xem l�i �i�u ki�n/tt_learn")
		end
		return
	end

	-- Hoc phi: kiem tra du CA HAI truoc khi tru bat cu thu gi
	if (t.tiendong < TT_COST_TIENDONG) then
		Say("L� nh�p m�n c�n <color=yellow>"..TT_COST_TIENDONG.." Ti�n ��ng<color>. Ng��i m�i c� "
			..t.tiendong..".", 0)
		return
	end

	if (t.cash < TT_COST_CASH) then
		Say("L� nh�p m�n c�n <color=yellow>"..floor(TT_COST_CASH/10000)
			.." v�n l��ng<color>. Ng��i mang ch�a ��.", 0)
		return
	end

	-- Thu hoc phi
	if (ConsumeItem(3, TT_COST_TIENDONG, 4, TT_ITEM_TIENDONG_D, 1, -1) ~= 1) then
		Msg2Player("<color=yellow>Thu Ti�n ��ng th�t b�i, xin th� l�i.<color>")
		WriteLog(GetLocalDate("%Y-%m-%d %X").."\t[ThatTruyen][LOI] Consume TienDong that bai"
			.."\tAccount:"..GetAccount().."\tName:"..GetName())
		return
	end
	Pay(TT_COST_CASH)

	-- Trao skill
	local szLearned = ""
	for i = 1, getn(tCanLearn) do
		AddMagic(tCanLearn[i], TT_SKILL_LEVEL)
		szLearned = szLearned.." "..tCanLearn[i]
	end

	WriteLog(GetLocalDate("%Y-%m-%d %X").."\t[ThatTruyen]\tAccount:"..GetAccount()
		.."\tName:"..GetName().."\tFaction:"..t.faction.."\tLearned:"..getn(tCanLearn)
		.."\tSkillId:"..szLearned
		.."\tTongKim:"..t.tongkim.."\tDaTau:"..t.datau
		.."\tPaid:"..TT_COST_TIENDONG.."TD+"..TT_COST_CASH.."L")

	Msg2Player("<color=yellow>Ng��i �� l�nh h�i "..getn(tCanLearn)
		.." m�n v� h�c th�t truy�n c�a b�n m�n!<color>")
	Say("B� v� h�c n�y th�t truy�n �� l�u. Nay ta truy�n l�i cho ng��i, h�y kh�ng ph� l�ng b�n m�n.", 0)

end

-- Giu lai cho tuong thich: mo bang dieu kien
function tt_info()
	tt_learn()
end
