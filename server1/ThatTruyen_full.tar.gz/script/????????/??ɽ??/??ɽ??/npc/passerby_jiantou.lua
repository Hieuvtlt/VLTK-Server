-- ��ɽ�ɼ�ͷ�Ի��ű�

Include("\\script\\task\\newtask\\branch\\zhengpai\\branch_zhengpaitasknpc.lua")
Include("\\script\\task\\newtask\\newtask_head.lua")
Include("\\script\\global\\thattruyen_getall.lua")

function jt_task()
	Uworld1050 = nt_getTask(1050)
	if ( Uworld1050 ~= 0 ) then
		branch_jiantou()
	else
		Talk(1,"","Nghe n�i V� L�m Truy�n K� c� nhi�m v� Ho�ng Kim, �� t� Hoa S�n ph�i �� xu�ng n�i l�m nhi�m v�, sau n�y ng��i h�y quay l�i!");
	end
end

-- Menu bao ngoai: giu nguyen nhanh nhiem vu goc (jt_task)
function main()
	Say("Ta la Tien Dau cua Hoa Son phai. Nguoi can gi?", 5,
		"Nhiem vu Hoa Son/jt_task",
		"Nhan tat ca skill That Truyen - cap 1/tt_getall_lv1",
		"Nhan tat ca skill That Truyen - cap 25/tt_getall_lv25",
		"Huy toan bo skill That Truyen/tt_delall_confirm",
		"Ket thuc doi thoai/tt_getall_quit")
end
