Include("\\script\\lib\\common.lua")
Include("\\script\\dailogsys\\g_dialog.lua")
Include("\\script\\dailogsys\\dailogsay.lua")

-- ================= H�M CH�NH N?M TR�N C�NG =================
function main()
	local nMonth = tonumber(GetLocalDate("%m"))
	
	-- B?Y TH?I GIAN: KH�A D?CH V? N?U KH�NG PH?I TH�NG 2
	if nMonth ~= 2 then
		local szMsg_Close = "<color=pink>Nguy�t L�o:<color>\nS� ki�n Valentine �� k�t th�c. H�n g�p l�i ��i hi�p v�o th�ng 2 n�m sau!"
		local tbOpt_Close = {
			{"Tho�t", KetThuc}
		}
		CreateNewSayEx(szMsg_Close, tbOpt_Close)
		return 1
	end

	-- MENU HO?T �?NG B�NH THU?NG TRONG TH�NG 2
	local szMsg = "<color=pink>Nguy�t L�o:<color>\nCh�c m�ng L� T�nh Nh�n! T�nh y�u lu�n c�n s� v� tha v� nh�ng m�n qu� ng�t ng�o. Ng��i mu�n gh�p v�t ph�m g�?"
	local tbOpt = {
		{"Gh�p Socola T�nh Y�u", Menu_GhepSocola},
		{"Gh�p Socola H�nh Nh�n", Menu_GhepSocolaHanhNhan},
		{"Mua H�nh Nh�n b�ng Ti�n ��ng", Menu_MuaHanhNhan},
		{"Tho�t", KetThuc}
	}
	CreateNewSayEx(szMsg, tbOpt)
	return 1
end

function Menu_SuKien_Thang2()
	main()
end

-- ================= MENU CH?N S? LU?NG =================
function Menu_GhepSocola()
	local tbOpt = {
		{"Gh�p 1 c�i", GhepSC_1}, {"Gh�p 10 c�i", GhepSC_10},
		{"Gh�p 50 c�i", GhepSC_50}, {"Gh�p 100 c�i", GhepSC_100},
		{"Quay l�i", main}
	}
	CreateNewSayEx("C�n: 1 ���ng C�t, 1 B�t M�, 1 Tr�ng, 1 S�a T��i, 1 Socola v� 3 v�n l��ng. Ch�n s� l��ng:", tbOpt)
end

function Menu_GhepSocolaHanhNhan()
	local tbOpt = {
		{"Gh�p 1 c�i", GhepSCHN_1}, {"Gh�p 10 c�i", GhepSCHN_10},
		{"Gh�p 50 c�i", GhepSCHN_50}, {"Gh�p 100 c�i", GhepSCHN_100},
		{"Quay l�i", main}
	}
	CreateNewSayEx("C�n: 1 B� nguy�n li�u l�m Socola v� 1 H�nh Nh�n. Ch�n s� l��ng:", tbOpt)
end

function Menu_MuaHanhNhan()
	local tbOpt = {
		{"Mua 1 H�nh Nh�n", MuaHN_1}, {"Mua 10 H�nh Nh�n", MuaHN_10},
		{"Mua 50 H�nh Nh�n", MuaHN_50}, {"Mua 100 H�nh Nh�n", MuaHN_100},
		{"Quay l�i", main}
	}
	CreateNewSayEx("1 Ti�n ��ng ��i 1 H�nh Nh�n. Ch�n s� l��ng:", tbOpt)
end

-- ================= H�M H? TR? KI?M TRA & TR? �? =================
function CheckNguyenLieu(nCount)
	if CalcEquiproomItemCount(6, 1, 5139, -1) < nCount then return 0 end
	if CalcEquiproomItemCount(6, 1, 5140, -1) < nCount then return 0 end
	if CalcEquiproomItemCount(6, 1, 5141, -1) < nCount then return 0 end
	if CalcEquiproomItemCount(6, 1, 5142, -1) < nCount then return 0 end
	if CalcEquiproomItemCount(6, 1, 5143, -1) < nCount then return 0 end
	return 1
end

function ConsumeNguyenLieu(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 5139, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 5140, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 5141, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 5142, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 5143, -1)
end

-- ================= LOGIC X? L� CH�NH =================
function TienHanh_GhepSocola(nCount)
	local nCost = nCount * 30000
	
	if CheckNguyenLieu(nCount) == 0 then
		Msg2Player("H�nh trang kh�ng c� �� " .. nCount .. " b� nguy�n li�u Socola!")
		return
	end
	if GetCash() < nCost then
		Msg2Player("Ng��i kh�ng c� �� " .. (nCount * 3) .. " v�n l��ng!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	Pay(nCost)
	ConsumeNguyenLieu(nCount)
	for i = 1, nCount do
		AddItem(6, 1, 5144, 1, 0, 0)
	end
	Msg2Player("Gh�p th�nh c�ng " .. nCount .. " Socola T�nh Y�u!")
end

function TienHanh_GhepSocolaHanhNhan(nCount)
	-- Socola H?nh Nh�n T�nh Y�u (Gi?ng B�nh H?o H?ng, kh�ng tr? lu?ng)
	if CheckNguyenLieu(nCount) == 0 then
		Msg2Player("H�nh trang kh�ng c� �� " .. nCount .. " b� nguy�n li�u Socola!")
		return
	end
	if CalcEquiproomItemCount(6, 1, 5138, -1) < nCount then
		Msg2Player("Kh�ng �� " .. nCount .. " H�nh Nh�n!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	ConsumeNguyenLieu(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 5138, -1)
	
	for i = 1, nCount do
		AddItem(6, 1, 5145, 1, 0, 0)
	end
	Msg2Player("Gh�p th�nh c�ng " .. nCount .. " Socola H�nh Nh�n T�nh Y�u!")
end

function TienHanh_MuaHanhNhan(nCount)
	if CalcEquiproomItemCount(4, 417, 1, -1) < nCount then
		Msg2Player("Ng��i kh�ng c� �� " .. nCount .. " Ti�n ��ng!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	ConsumeEquiproomItem(nCount, 4, 417, 1, -1)
	for i = 1, nCount do
		AddItem(6, 1, 5138, 1, 0, 0)
	end
	Msg2Player("Mua th�nh c�ng " .. nCount .. " H�nh Nh�n b�ng Ti�n ��ng!")
end

-- ================= WRAPPERS G?I H�M =================
function GhepSC_1() TienHanh_GhepSocola(1) end
function GhepSC_10() TienHanh_GhepSocola(10) end
function GhepSC_50() TienHanh_GhepSocola(50) end
function GhepSC_100() TienHanh_GhepSocola(100) end

function GhepSCHN_1() TienHanh_GhepSocolaHanhNhan(1) end
function GhepSCHN_10() TienHanh_GhepSocolaHanhNhan(10) end
function GhepSCHN_50() TienHanh_GhepSocolaHanhNhan(50) end
function GhepSCHN_100() TienHanh_GhepSocolaHanhNhan(100) end

function MuaHN_1() TienHanh_MuaHanhNhan(1) end
function MuaHN_10() TienHanh_MuaHanhNhan(10) end
function MuaHN_50() TienHanh_MuaHanhNhan(50) end
function MuaHN_100() TienHanh_MuaHanhNhan(100) end

function KetThuc() end