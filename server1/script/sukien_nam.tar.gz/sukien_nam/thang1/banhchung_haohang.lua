Include("\\script\\lib\\common.lua")
Include("\\script\\lib\\awardtemplet.lua")
Include("\\script\\task\\task_addplayerexp.lua")

-- ================= B?NG PH?N THU?NG G?P CHUNG (CHU?N TCVN3) =================
tb_QuaBanhChung = {
	[1]  = {szName="Kim Quang B�t K�nh Chi M�ng", nQuality=1, tbProp={0, 197}, nRate = 0.02},
	[2]  = {szName="Kim Quang Nh� �i�n Chi H�n", nQuality=1, tbProp={0, 202}, nRate = 0.02},
	[3]  = {szName="Thi�n S�n Tuy�t Li�n", tbProp={6,1,1431,1,0,0}, nRate = 0.01},
	[4]  = {szName="T� Th�y Tinh", tbProp = {4, 239, 1, 1, 0, 0}, nRate = 3},
	[5]  = {szName="Lam Th�y Tinh", tbProp = {4, 238, 1, 1, 0, 0}, nRate = 2},
	[6]  = {szName="L�c Th�y Tinh", tbProp = {4, 240, 1, 1, 0, 0}, nRate = 2},
	[7]  = {szName="Tinh H�ng B�o Th�ch", tbProp = {4, 353, 1, 1, 0, 0}, nRate = 1},
	[8]  = {szName="Hu�n C�ng Ch��ng", tbProp = {6, 1, 5129, 1, 0, 0}, nRate = 5},
	[9]  = {szName="C�ng Tr�ng L�nh", tbProp = {6, 1, 5130, 1, 0, 0}, nRate = 5},
	[10] = {szName="Huy�n tinh kho�ng th�ch c�p 3", tbProp = {6, 1, 147, 3, 0, 0}, nRate = 20},
	[11] = {szName="Huy�n tinh kho�ng th�ch c�p 4", tbProp = {6, 1, 147, 4, 0, 0}, nRate = 15},
	[12] = {szName="Huy�n tinh kho�ng th�ch c�p 5", tbProp = {6, 1, 147, 5, 0, 0}, nRate = 10},
	[13] = {szName="Huy�n tinh kho�ng th�ch c�p 6", tbProp = {6, 1, 147, 6, 0, 0}, nRate = 5},
	[14] = {szName="Huy�n tinh kho�ng th�ch c�p 7", tbProp = {6, 1, 147, 7, 0, 0}, nRate = 0.1},
	[15] = {szName="Huy�n tinh kho�ng th�ch c�p 8", tbProp = {6, 1, 147, 8, 0, 0}, nRate = 0.05},
	[16] = {szName="Phi T�c Ho�n", tbProp = {6, 0, 6, 1, 0, 0}, nRate = 5},
	[17] = {szName="��i L�c Ho�n", tbProp = {6, 0, 3, 1, 0, 0}, nRate = 5},
	[18] = {szName="Ph�c Duy�n L� (��i)", tbProp = {6, 1, 124, 1, 0, 0}, nRate = 5},
	[19] = {szName="Kim Quang Tr�ch Tinh Ho�n", nQuality=1, tbProp={0, 194}, nRate = 0.02},
	[20] = {szName="Kim Quang ���ng Ngh� Gi�p", nQuality=1, tbProp={0, 195}, nRate = 0.02},
	[21] = {szName="Kim Quang L�c Phi Th�y H�a Th�n Ph�", nQuality=1, tbProp={0, 196}, nRate = 0.02},
	[22] = {szName="Kim Quang B�ch Kim Y�u ��i", nQuality=1, tbProp={0, 198}, nRate = 0.02},
	[23] = {szName="Kim Quang Thi�n T�m H� Uy�n", nQuality=1, tbProp={0, 199}, nRate = 0.02},
	[24] = {szName="Kim Quang Ng� S�c Ng�c B�i", nQuality=1, tbProp={0, 200}, nRate = 0.02},
	[25] = {szName="Kim Quang Thi�n T�m Ngoa", nQuality=1, tbProp={0, 201}, nRate = 0.02},
	[26] = {szName="V� L�m M�t T�ch", tbProp={6, 1, 26, 1, 0, 0}, nRate = 0.5},
	[27] = {szName="T�y T�y Kinh", tbProp={6, 1, 22, 1, 0, 0}, nRate = 0.5},
	[28] = {szName="C�ng Nguy�t Qu� Dung", tbProp={6, 1, 128, 1, 0, 0}, nRate = 0.5},
	[29] = {szName="Ph�ng Nguy�t Qu� Dung", tbProp={6, 1, 127, 1, 0, 0}, nRate = 0.5},
	
	-- B? D?NG S�T (143 -> 146)
	[30] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 143}, nRate = 0.005},
	[31] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 144}, nRate = 0.005},
	[32] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 145}, nRate = 0.005},
	[33] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 146}, nRate = 0.005},
	
	-- B? D?NH QU?C & AN BANG (159 -> 168)
	[34] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 159}, nRate = 0.004},
	[35] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 160}, nRate = 0.004},
	[36] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 161}, nRate = 0.004},
	[37] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 162}, nRate = 0.004},
	[38] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 163}, nRate = 0.004},
	[39] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 164}, nRate = 0.004},
	[40] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 165}, nRate = 0.004},
	[41] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 166}, nRate = 0.004},
	[42] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 167}, nRate = 0.004},
	[43] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 168}, nRate = 0.004},
	
	-- B? NHU T�NH & HI?P C?T (186 -> 193)
	[44] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 186}, nRate = 0.005},
	[45] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 187}, nRate = 0.005},
	[46] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 188}, nRate = 0.005},
	[47] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 189}, nRate = 0.005},
	[48] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 190}, nRate = 0.005},
	[49] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 191}, nRate = 0.005},
	[50] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 192}, nRate = 0.005},
	[51] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 193}, nRate = 0.005},
}

-- T? D?NG CH�N 119 D�NG HO�NG KIM M�N PH�I (5314 -> 5432)
local nIndex = 52
for nId = 5314, 5432 do
	tb_QuaBanhChung[nIndex] = {szName="Trang b� Ho�ng Kim M�n Ph�i", nQuality=1, tbProp={0, nId}, nRate = 0.00002}
	nIndex = nIndex + 1
end

function main(nItemIdx)
	local TSK_TONG_EXP = 1310
	local TSK_NAM_EVENT = 1311
	local MAX_EXP = 1500000000
	local nMonth = tonumber(GetLocalDate("%m"))
	local nYear = tonumber(GetLocalDate("%Y"))

	if nMonth ~= 1 then
		Msg2Player("<color=red>B�nh Ch�ng �� h�t h�n, b� �i thiu v� �� b� v�t b�!<color>")
		return 1
	end

	local nNamCu = GetTask(TSK_NAM_EVENT)
	if nNamCu ~= nYear then
		SetTask(TSK_TONG_EXP, 0) 
		SetTask(TSK_NAM_EVENT, nYear) 
	end

	local nExpDaNhan = GetTask(TSK_TONG_EXP)
	if nExpDaNhan >= MAX_EXP then
		Msg2Player("<color=red>��i hi�p �� nh�n t�i �a 1.5 T� Kinh Nghi�m, kh�ng th� �n th�m B�nh Ch�ng!<color>")
		return 1
	end

	if CalcFreeItemCellCount() < 2 then
		Msg2Player("H�nh trang c�n �t nh�t 2 � tr�ng �� nh�n th��ng!")
		return 1
	end

	-- X�a ch�nh x�c v?t ph?m dang click b?ng GetItemProp
	local nG, nD, nP = GetItemProp(nItemIdx)
	if ConsumeEquiproomItem(1, nG, nD, nP, -1) ~= 1 then
		Msg2Player("H� th�ng b�n, kh�ng th� s� d�ng v�t ph�m l�c n�y!")
		return 1
	end

	-- Ch?t c?ng 5 tri?u EXP
	local nAddExp = 5000000
	if nExpDaNhan + nAddExp > MAX_EXP then nAddExp = MAX_EXP - nExpDaNhan end
	
	tl_addPlayerExp(nAddExp)
	SetTask(TSK_TONG_EXP, nExpDaNhan + nAddExp)
	
	-- B?c ph?n thu?ng t? b?ng duy nh?t
	tbAwardTemplet:GiveAwardByList(tb_QuaBanhChung, "B�nh Ch�ng H�o H�ng")
	
	Msg2Player("<color=yellow>S� d�ng th�nh c�ng, nh�n ���c 500 v�n Kinh Nghi�m v� ph�n qu� b�t ng�!<color>")
	return 1
end