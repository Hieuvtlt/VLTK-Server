Include("\\script\\lib\\common.lua")
Include("\\script\\lib\\awardtemplet.lua")
Include("\\script\\task\\task_addplayerexp.lua")

tb_QuaBanhNhuY = {
	[1]  = {szName="T� Th�y Tinh", tbProp={4, 239, 1, 1, 0, 0}, nRate=0},
	[2]  = {szName="Lam Th�y Tinh", tbProp={4, 238, 1, 1, 0, 0}, nRate=0},
	[3]  = {szName="L�c Th�y Tinh", tbProp={4, 240, 1, 1, 0, 0}, nRate=0},
	[4]  = {szName="Tinh H�ng B�o Th�ch", tbProp={4, 353, 1, 1, 0, 0}, nRate=0},
	[5]  = {szName="Hu�n C�ng Ch��ng", tbProp={6, 1, 5129, 1, 0, 0}, nRate=25},
	[6]  = {szName="C�ng Tr�ng L�nh", tbProp={6, 1, 5130, 1, 0, 0}, nRate=25},
	[7]  = {szName="Huy�n tinh kho�ng th�ch c�p 3", tbProp={6, 1, 147, 3, 0, 0}, nRate=0},
	[8]  = {szName="Huy�n tinh kho�ng th�ch c�p 4", tbProp={6, 1, 147, 4, 0, 0}, nRate=0},
	[9]  = {szName="Huy�n tinh kho�ng th�ch c�p 5", tbProp={6, 1, 147, 5, 0, 0}, nRate=0},
	[10] = {szName="V�t ph�m ng�u nhi�n 1", tbProp={6, 1, 33, 1, 0, 0}, nRate=0}, 
	[11] = {szName="V�t ph�m ng�u nhi�n 2", tbProp={6, 1, 45, 1, 0, 0}, nRate=0}, 
	[12] = {szName="M�nh trang b� Ho�ng Kim", tbProp={6, 1, 5128, 1, 0, 0}, nRate=0},
	[13] = {szName="Phi T�c Ho�n", tbProp={6, 0, 6, 1, 0, 0}, nRate=50},
	[14] = {szName="��i L�c Ho�n", tbProp={6, 0, 3, 1, 0, 0}, nRate=50},
	[15] = {szName="Ph�c Duy�n L� (��i)", tbProp={6, 1, 124, 1, 0, 0}, nRate=25}
}

function main(nItemIdx)
	local TSK_TONG_EXP = 1401
	local TSK_NAM_EVENT = 1402
	local MAX_EXP = 1000000000 -- 1 Ty EXP
	local nMonth = tonumber(GetLocalDate("%m"))
	local nYear = tonumber(GetLocalDate("%Y"))

	if nMonth ~= 6 then
		Msg2Player("<color=red>B�nh Kem �� h�t h�n, b� h�ng v� �� b� v�t b�!<color>")
		return 1
	end

	local nNamCu = GetTask(TSK_NAM_EVENT)
	if nNamCu ~= nYear then
		SetTask(TSK_TONG_EXP, 0) 
		SetTask(TSK_NAM_EVENT, nYear) 
	end

	local nExpDaNhan = GetTask(TSK_TONG_EXP)
	if nExpDaNhan >= MAX_EXP then
		Msg2Player("<color=red>��i hi�p �� nh�n t�i �a 1 T� Kinh Nghi�m m�a n�y, kh�ng th� �n th�m!<color>")
		return 1
	end

	if CalcFreeItemCellCount() < 2 then
		Msg2Player("H�nh trang c�n �t nh�t 2 � tr�ng �� nh�n th��ng!")
		return 1
	end

	local nG, nD, nP = GetItemProp(nItemIdx)
	if ConsumeEquiproomItem(1, nG, nD, nP, -1) ~= 1 then
		Msg2Player("H� th�ng b�n, kh�ng th� s� d�ng v�t ph�m l�c n�y!")
		return 1
	end

	local nAddExp = 3000000
	if nExpDaNhan + nAddExp > MAX_EXP then nAddExp = MAX_EXP - nExpDaNhan end
	
	tl_addPlayerExp(nAddExp)
	SetTask(TSK_TONG_EXP, nExpDaNhan + nAddExp)
	
	tb_QuaBanhNhuY[10].tbProp[3] = random(33, 43)
	tb_QuaBanhNhuY[11].tbProp[3] = random(45, 62)
	
	tbAwardTemplet:GiveAwardByList(tb_QuaBanhNhuY, "B�nh Kem Nh� �")
	
	Msg2Player("<color=yellow>Th��ng th�c th�nh c�ng, nh�n ���c " .. (nAddExp/10000) .. " v�n Kinh Nghi�m!<color>")
	return 1
end