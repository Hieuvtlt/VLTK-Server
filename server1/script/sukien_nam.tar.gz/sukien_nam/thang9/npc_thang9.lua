Include("\\script\\lib\\common.lua")
Include("\\script\\dailogsys\\g_dialog.lua")
Include("\\script\\dailogsys\\dailogsay.lua")

-- ================= H�M CH�NH N?M TR�N C�NG =================
function main()
	local nMonth = tonumber(GetLocalDate("%m"))
	
	-- KH�A D?CH V? N?U KH�NG PH?I TH�NG 9
	if nMonth ~= 9 then
		local szMsg_Close = "<color=yellow>S� Gi� Qu�c Kh�nh:<color>\nS� ki�n Qu�c Kh�nh �� k�t th�c. H�n g�p l�i ��i hi�p v�o th�ng 9 n�m sau!"
		local tbOpt_Close = {
			{"Tho�t", KetThuc}
		}
		CreateNewSayEx(szMsg_Close, tbOpt_Close)
		return 1
	end

	-- MENU HO?T D?NG B�NH THU?NG TRONG TH�NG 9
	local szMsg = "<color=yellow>S� Gi� Qu�c Kh�nh:<color>\nCh�o m�ng ��i hi�p ��n v�i s� ki�n Qu�c Kh�nh! Ng��i mu�n th�c hi�n giao d�ch g�?"
	local tbOpt = {
		{"Gh�p Chi�c M� Tai B�o", Menu_GhepTaiBeo},
		{"Gh�p Huy Ch��ng Qu�c Kh�nh", Menu_GhepHuyChuong},
		{"Mua Ng�i Sao Chi�n Th�ng (Ti�n ��ng)", Menu_MuaNgoiSao},
		{"Tho�t", KetThuc}
	}
	CreateNewSayEx(szMsg, tbOpt)
	return 1
end

function Menu_SuKien_Thang()
	main()
end

-- ================= MENU CH?N S? LU?NG =================
function Menu_GhepTaiBeo()
	local tbOpt = {
		{"Gh�p 1 c�i", GhepMTB_1}, {"Gh�p 10 c�i", GhepMTB_10},
		{"Gh�p 50 c�i", GhepMTB_50}, {"Gh�p 100 c�i", GhepMTB_100},
		{"Quay l�i", main}
	}
	CreateNewSayEx("C�n: 1 M� Ho� B�nh, 1 M� T� Do, 1 M� H�nh Ph�c v� 3 v�n l��ng. Ch�n s� l��ng:", tbOpt)
end

function Menu_GhepHuyChuong()
	local tbOpt = {
		{"Gh�p 1 c�i", GhepMHC_1}, {"Gh�p 10 c�i", GhepMHC_10},
		{"Gh�p 50 c�i", GhepMHC_50}, {"Gh�p 100 c�i", GhepMHC_100},
		{"Quay l�i", main}
	}
	CreateNewSayEx("C�n: 1 M� Ho� B�nh, 1 M� T� Do, 1 M� H�nh Ph�c v� 1 Ng�i Sao Chi�n Th�ng. Ch�n s� l��ng:", tbOpt)
end

function Menu_MuaNgoiSao()
	local tbOpt = {
		{"Mua 1 Ng�i Sao", MuaSao_1}, {"Mua 10 Ng�i Sao", MuaSao_10},
		{"Mua 50 Ng�i Sao", MuaSao_50}, {"Mua 100 Ng�i Sao", MuaSao_100},
		{"Quay l�i", main}
	}
	CreateNewSayEx("1 Ti�n ��ng ��i ���c 1 Ng�i Sao Chi�n Th�ng. Ch�n s� l��ng:", tbOpt)
end

-- ================= H�M H? TR? KI?M TRA & TR? D? =================
function CheckBaMu(nCount)
	if CalcEquiproomItemCount(6, 1, 2098, -1) < nCount then return 0 end -- Mu h�a b�nh
	if CalcEquiproomItemCount(6, 1, 2099, -1) < nCount then return 0 end -- Mu t? do
	if CalcEquiproomItemCount(6, 1, 2100, -1) < nCount then return 0 end -- Mu h?nh ph�c
	return 1
end

function ConsumeBaMu(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 2098, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 2099, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 2100, -1)
end

-- ================= LOGIC X? L� CH�NH =================
function TienHanh_GhepTaiBeo(nCount)
	local nCost = nCount * 30000
	
	if CheckBaMu(nCount) == 0 then
		Msg2Player("H�nh trang kh�ng c� �� " .. nCount .. " b� (M� Ho� B�nh + T� Do + H�nh Ph�c)!")
		return
	end
	if GetCash() < nCost then
		Msg2Player("Ng��i kh�ng c� �� " .. (nCount * 3) .. " v�n l��ng!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng �� gh�p ��!")
		return
	end
	
	Pay(nCost)
	ConsumeBaMu(nCount)
	
	for i = 1, nCount do
		AddItem(6, 1, 2097, 1, 0, 0) -- Add Mu Tai B�o
	end
	Msg2Player("Gh�p th�nh c�ng " .. nCount .. " Chi�c M� Tai B�o!")
end

function TienHanh_GhepHuyChuong(nCount)
	if CheckBaMu(nCount) == 0 then
		Msg2Player("H�nh trang kh�ng c� �� " .. nCount .. " b� (M� Ho� B�nh + T� Do + H�nh Ph�c)!")
		return
	end
	if CalcEquiproomItemCount(6, 1, 1494, -1) < nCount then
		Msg2Player("Kh�ng �� " .. nCount .. " Ng�i Sao Chi�n Th�ng!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng �� gh�p ��!")
		return
	end
	
	ConsumeBaMu(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 1494, -1)
	
	for i = 1, nCount do
		AddItem(6, 1, 1496, 1, 0, 0) -- Add Huy Chuong Qu?c Kh�nh
	end
	Msg2Player("Gh�p th�nh c�ng " .. nCount .. " Huy Ch��ng Qu�c Kh�nh!")
end

function TienHanh_MuaNgoiSao(nCount)
	if CalcEquiproomItemCount(4, 417, 1, -1) < nCount then
		Msg2Player("Ng��i kh�ng c� �� " .. nCount .. " Ti�n ��ng!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	ConsumeEquiproomItem(nCount, 4, 417, 1, -1)
	
	for i = 1, nCount do
		AddItem(6, 1, 1494, 1, 0, 0) -- Add Ng�i Sao Chi?n Th?ng
	end
	Msg2Player("Mua th�nh c�ng " .. nCount .. " Ng�i Sao Chi�n Th�ng b�ng Ti�n ��ng!")
end

-- ================= WRAPPERS G?I H�M =================
function GhepMTB_1() TienHanh_GhepTaiBeo(1) end
function GhepMTB_10() TienHanh_GhepTaiBeo(10) end
function GhepMTB_50() TienHanh_GhepTaiBeo(50) end
function GhepMTB_100() TienHanh_GhepTaiBeo(100) end

function GhepMHC_1() TienHanh_GhepHuyChuong(1) end
function GhepMHC_10() TienHanh_GhepHuyChuong(10) end
function GhepMHC_50() TienHanh_GhepHuyChuong(50) end
function GhepMHC_100() TienHanh_GhepHuyChuong(100) end

function MuaSao_1() TienHanh_MuaNgoiSao(1) end
function MuaSao_10() TienHanh_MuaNgoiSao(10) end
function MuaSao_50() TienHanh_MuaNgoiSao(50) end
function MuaSao_100() TienHanh_MuaNgoiSao(100) end

function KetThuc() end