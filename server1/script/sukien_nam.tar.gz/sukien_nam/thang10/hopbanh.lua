Include("\\script\\lib\\common.lua")
Include("\\script\\lib\\awardtemplet.lua")
Include("\\script\\task\\task_addplayerexp.lua")

-- ================= B?NG PH?N THU?NG (D� B? 2 LO?I HO�N) =================
tb_QuaTrungThu = {
	[1]  = {szName="Kim Quang B�t K�nh Chi M�ng", nQuality=1, tbProp={0, 197}, nRate = 0.06},
	[2]  = {szName="Kim Quang Nh� �i�n Chi H�n", nQuality=1, tbProp={0, 202}, nRate = 0.06},
	[3]  = {szName="Thi�n S�n Tuy�t Li�n", tbProp={6,1,1431,1,0,0}, nRate = 0.03},
	[4]  = {szName="Kim Quang Tr�ch Tinh Ho�n", nQuality=1, tbProp={0, 194}, nRate = 0.06},
	[5]  = {szName="Kim Quang ���ng Ngh� Gi�p", nQuality=1, tbProp={0, 195}, nRate = 0.06},
	[6]  = {szName="Kim Quang L�c Phi Th�y H�a Th�n Ph�", nQuality=1, tbProp={0, 196}, nRate = 0.06},
	[7]  = {szName="Kim Quang B�ch Kim Y�u ��i", nQuality=1, tbProp={0, 198}, nRate = 0.06},
	[8]  = {szName="Kim Quang Thi�n T�m H� Uy�n", nQuality=1, tbProp={0, 199}, nRate = 0.06},
	[9]  = {szName="Kim Quang Ng� S�c Ng�c B�i", nQuality=1, tbProp={0, 200}, nRate = 0.06},
	[10] = {szName="Kim Quang Thi�n T�m Ngoa", nQuality=1, tbProp={0, 201}, nRate = 0.06},
	[11] = {szName="V� L�m M�t T�ch", tbProp={6, 1, 26, 1, 0, 0}, nRate = 1.5},
	[12] = {szName="T�y T�y Kinh", tbProp={6, 1, 22, 1, 0, 0}, nRate = 1.5},
	[13] = {szName="C�ng Nguy�t Qu� Dung", tbProp={6, 1, 128, 1, 0, 0}, nRate = 1.5},
	[14] = {szName="Ph�ng Nguy�t Qu� Dung", tbProp={6, 1, 127, 1, 0, 0}, nRate = 1.5},
	
	-- TRANG B? D?NG S�T
	[15] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 143}, nRate = 0.015},
	[16] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 144}, nRate = 0.015},
	[17] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 145}, nRate = 0.015},
	[18] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 146}, nRate = 0.015},
	
	-- TRANG B? D?NH QU?C & AN BANG
	[19] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 159}, nRate = 0.012},
	[20] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 160}, nRate = 0.012},
	[21] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 161}, nRate = 0.012},
	[22] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 162}, nRate = 0.012},
	[23] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 163}, nRate = 0.012},
	[24] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 164}, nRate = 0.012},
	[25] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 165}, nRate = 0.012},
	[26] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 166}, nRate = 0.012},
	[27] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 167}, nRate = 0.012},
	[28] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 168}, nRate = 0.012},
	
	-- TRANG B? NHU T�NH & HI?P C?T
	[29] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 186}, nRate = 0.015},
	[30] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 187}, nRate = 0.015},
	[31] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 188}, nRate = 0.015},
	[32] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 189}, nRate = 0.015},
	[33] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 190}, nRate = 0.015},
	[34] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 191}, nRate = 0.015},
	[35] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 192}, nRate = 0.015},
	[36] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 193}, nRate = 0.015},
}

-- T? D?NG CH�N 119 D�NG HO�NG KIM (D� d?n s? th? t?)
local nIndex = 37
for nId = 5314, 5432 do
	tb_QuaTrungThu[nIndex] = {szName="Trang b� Ho�ng Kim", nQuality=1, tbProp={0, nId}, nRate = 0.00006}
	nIndex = nIndex + 1
end

function main(nItemIdx)
	local TSK_TONG_EXP = 1312
	local TSK_NAM_EVENT = 1311
	local MAX_EXP = 1500000000
	local nMonth = tonumber(GetLocalDate("%m"))
	local nYear = tonumber(GetLocalDate("%Y"))

	-- KI?M TRA H?N S? D?NG
	if nMonth ~= 10 then
		Msg2Player("<color=red>H�p B�nh Trung Thu �� h�t h�n, b� �i thiu v� �� b� v�t b�!<color>")
		return 1
	end

	local nNamCu = GetTask(TSK_NAM_EVENT)
	if nNamCu ~= nYear then
		SetTask(TSK_TONG_EXP, 0) 
		SetTask(TSK_NAM_EVENT, nYear) 
	end

	local nExpDaNhan = GetTask(TSK_TONG_EXP)
	if nExpDaNhan >= MAX_EXP then
		Msg2Player("<color=red>��i hi�p �� nh�n t�i �a 1.5 T� Kinh Nghi�m t� H�p B�nh, kh�ng th� d�ng th�m!<color>")
		return 1
	end

	if CalcFreeItemCellCount() < 2 then
		Msg2Player("H�nh trang c�n �t nh�t 2 � tr�ng �� nh�n th��ng!")
		return 1
	end

	local nG, nD, nP = GetItemProp(nItemIdx)
	if ConsumeEquiproomItem(1, nG, nD, nP, -1) ~= 1 then
		Msg2Player("H� th�ng b�n, kh�ng th� s� d�ng v�t ph�m l�c n�y!")
		return 1
	end

	-- C?NG 10 TRI?U EXP
	local nAddExp = 10000000
	if nExpDaNhan + nAddExp > MAX_EXP then nAddExp = MAX_EXP - nExpDaNhan end
	
	tl_addPlayerExp(nAddExp)
	SetTask(TSK_TONG_EXP, nExpDaNhan + nAddExp)
	
	tbAwardTemplet:GiveAwardByList(tb_QuaTrungThu, "H�p B�nh Trung Thu")
	Msg2Player("<color=yellow>S� d�ng th�nh c�ng, nh�n ���c 1000 v�n Kinh Nghi�m v� ph�n qu� b�t ng�!<color>")
	return 1
end