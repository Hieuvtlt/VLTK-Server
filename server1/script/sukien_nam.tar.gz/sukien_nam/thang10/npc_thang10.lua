Include("\\script\\lib\\common.lua")
Include("\\script\\dailogsys\\g_dialog.lua")
Include("\\script\\dailogsys\\dailogsay.lua")

-- ================= H�M CH�NH =================
function main()
	local nMonth = tonumber(GetLocalDate("%m"))
	
	if nMonth ~= 10 then
		local szMsg_Close = "<color=yellow>H�ng Nga:<color>\nTr�ng r�m �� t�n, m�a Trung Thu �� k�t th�c. H�n g�p l�i ��i hi�p v�o th�ng 10 n�m sau!"
		local tbOpt_Close = {
			{"Tho�t", KetThuc}
		}
		CreateNewSayEx(szMsg_Close, tbOpt_Close)
		return 1
	end

	local szMsg = "<color=yellow>H�ng Nga:<color>\nTr�ng r�m s�ng t� nh� g��ng, ng��i ng��i n� n�c ��n T�t Trung Thu. Ng��i mu�n th�c hi�n giao d�ch g�?"
	local tbOpt = {
		{"L�m B�nh Trung Thu", Menu_LamBanh},
		{"Gh�p H�p B�nh Trung Thu", Menu_GhepHop},
		{"Mua Nguy�n Li�u Trung Thu", Menu_MuaNguyenLieu},
		{"Tho�t", KetThuc}
	}
	CreateNewSayEx(szMsg, tbOpt)
	return 1
end

function Menu_SuKien_Thang() main() end

-- ================= C�C MENU CH?N S? LU?NG =================
function Menu_LamBanh()
	local tbOpt = {
		{"B�nh ��u Xanh", Menu_BanhDauXanh},
		{"B�nh H�t Sen", Menu_BanhHatSen},
		{"B�nh G� N��ng", Menu_BanhGaNuong},
		{"B�nh Heo Quay", Menu_BanhHeoQuay},
		{"Quay l�i", main}
	}
	CreateNewSayEx("L�m b�nh c�n: 1 B�t, 1 ���ng, 1 Tr�ng v� 1 Nguy�n li�u ch�nh. Ch�n lo�i b�nh:", tbOpt)
end

function Menu_BanhDauXanh()
	local tbOpt = {
		{"L�m 1 c�i", LamBanhDX_1}, {"L�m 10 c�i", LamBanhDX_10},
		{"L�m 50 c�i", LamBanhDX_50}, {"L�m 100 c�i", LamBanhDX_100}, {"Quay l�i", Menu_LamBanh}
	}
	CreateNewSayEx("C�n: B�t + ���ng + Tr�ng + ��u Xanh. Ch�n s� l��ng:", tbOpt)
end

function Menu_BanhHatSen()
	local tbOpt = {
		{"L�m 1 c�i", LamBanhHS_1}, {"L�m 10 c�i", LamBanhHS_10},
		{"L�m 50 c�i", LamBanhHS_50}, {"L�m 100 c�i", LamBanhHS_100}, {"Quay l�i", Menu_LamBanh}
	}
	CreateNewSayEx("C�n: B�t + ���ng + Tr�ng + T�i H�t Sen. Ch�n s� l��ng:", tbOpt)
end

function Menu_BanhGaNuong()
	local tbOpt = {
		{"L�m 1 c�i", LamBanhGN_1}, {"L�m 10 c�i", LamBanhGN_10},
		{"L�m 50 c�i", LamBanhGN_50}, {"L�m 100 c�i", LamBanhGN_100}, {"Quay l�i", Menu_LamBanh}
	}
	CreateNewSayEx("C�n: B�t + ���ng + Tr�ng + T�i Th�t G�. Ch�n s� l��ng:", tbOpt)
end

function Menu_BanhHeoQuay()
	local tbOpt = {
		{"L�m 1 c�i", LamBanhHQ_1}, {"L�m 10 c�i", LamBanhHQ_10},
		{"L�m 50 c�i", LamBanhHQ_50}, {"L�m 100 c�i", LamBanhHQ_100}, {"Quay l�i", Menu_LamBanh}
	}
	CreateNewSayEx("C�n: B�t + ���ng + Tr�ng + Th�t Heo. Ch�n s� l��ng:", tbOpt)
end

function Menu_GhepHop()
	local tbOpt = {
		{"Gh�p 1 H�p", GhepHop_1}, {"Gh�p 10 H�p", GhepHop_10},
		{"Gh�p 50 H�p", GhepHop_50}, {"Gh�p 100 H�p", GhepHop_100}, {"Quay l�i", main}
	}
	CreateNewSayEx("C�n: 4 V� B�nh Trung Thu (DX, HS, GN, HQ). Ch�n s� l��ng:", tbOpt)
end

function Menu_MuaNguyenLieu()
	local tbOpt = {
		{"Mua T�i H�t Sen (3 v�n)", Menu_MuaHatSen},
		{"Mua T�i Th�t G� (5 v�n)", Menu_MuaThitGa},
		{"Mua Th�t Heo (1 Ti�n ��ng)", Menu_MuaThitHeo},
		{"Quay l�i", main}
	}
	CreateNewSayEx("Nguy�n li�u th�ng h�ng do Ch� H�ng ��ch th�n chu�n b�. Ng��i mu�n mua g�?", tbOpt)
end

function Menu_MuaHatSen()
	local tbOpt = {
		{"Mua 1 T�i", MuaHS_1}, {"Mua 10 T�i", MuaHS_10},
		{"Mua 50 T�i", MuaHS_50}, {"Mua 100 T�i", MuaHS_100}, {"Quay l�i", Menu_MuaNguyenLieu}
	}
	CreateNewSayEx("T�i H�t Sen gi� 3 v�n l��ng/t�i. Ch�n s� l��ng:", tbOpt)
end

function Menu_MuaThitGa()
	local tbOpt = {
		{"Mua 1 T�i", MuaTG_1}, {"Mua 10 T�i", MuaTG_10},
		{"Mua 50 T�i", MuaTG_50}, {"Mua 100 T�i", MuaTG_100}, {"Quay l�i", Menu_MuaNguyenLieu}
	}
	CreateNewSayEx("T�i Th�t G� gi� 5 v�n l��ng/t�i. Ch�n s� l��ng:", tbOpt)
end

function Menu_MuaThitHeo()
	local tbOpt = {
		{"Mua 1 T�i", MuaTH_1}, {"Mua 10 T�i", MuaTH_10},
		{"Mua 50 T�i", MuaTH_50}, {"Mua 100 T�i", MuaTH_100}, {"Quay l�i", Menu_MuaNguyenLieu}
	}
	CreateNewSayEx("Th�t Heo gi� 1 Ti�n ��ng/t�i. Ch�n s� l��ng:", tbOpt)
end


-- ================= H�M H? TR? KI?M TRA =================
function CheckNguyenLieuChung(nCount)
	if CalcEquiproomItemCount(6, 1, 1503, -1) < nCount then return 0 end -- Bot
	if CalcEquiproomItemCount(6, 1, 1504, -1) < nCount then return 0 end -- Duong
	if CalcEquiproomItemCount(6, 1, 1505, -1) < nCount then return 0 end -- Trung
	return 1
end

function ConsumeNguyenLieuChung(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 1503, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 1504, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 1505, -1)
end

function CheckBonBanh(nCount)
	if CalcEquiproomItemCount(6, 1, 1510, -1) < nCount then return 0 end 
	if CalcEquiproomItemCount(6, 1, 1511, -1) < nCount then return 0 end 
	if CalcEquiproomItemCount(6, 1, 1512, -1) < nCount then return 0 end 
	if CalcEquiproomItemCount(6, 1, 1513, -1) < nCount then return 0 end 
	return 1
end

function ConsumeBonBanh(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 1510, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 1511, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 1512, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 1513, -1)
end

-- ================= LOGIC N?U B�NH & GH�P H?P =================
function TienHanh_LamBanhDX(nCount)
	if CheckNguyenLieuChung(nCount) == 0 then
		Msg2Player("Kh�ng �� " .. nCount .. " b� (B�t + ���ng + Tr�ng)!")
		return
	end
	if CalcEquiproomItemCount(6, 1, 1506, -1) < nCount then
		Msg2Player("Kh�ng �� " .. nCount .. " ��u Xanh!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	ConsumeNguyenLieuChung(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 1506, -1)
	
	for i = 1, nCount do AddItem(6, 1, 1510, 1, 0, 0) end
	Msg2Player("L�m th�nh c�ng " .. nCount .. " B�nh ��u Xanh!")
end

function TienHanh_LamBanhHS(nCount)
	if CheckNguyenLieuChung(nCount) == 0 then
		Msg2Player("Kh�ng �� " .. nCount .. " b� (B�t + ���ng + Tr�ng)!")
		return
	end
	if CalcEquiproomItemCount(6, 1, 1507, -1) < nCount then
		Msg2Player("Kh�ng �� " .. nCount .. " T�i H�t Sen!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	ConsumeNguyenLieuChung(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 1507, -1)
	
	for i = 1, nCount do AddItem(6, 1, 1511, 1, 0, 0) end
	Msg2Player("L�m th�nh c�ng " .. nCount .. " B�nh H�t Sen!")
end

function TienHanh_LamBanhGN(nCount)
	if CheckNguyenLieuChung(nCount) == 0 then
		Msg2Player("Kh�ng �� " .. nCount .. " b� (B�t + ���ng + Tr�ng)!")
		return
	end
	if CalcEquiproomItemCount(6, 1, 1508, -1) < nCount then
		Msg2Player("Kh�ng �� " .. nCount .. " T�i Th�t G�!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	ConsumeNguyenLieuChung(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 1508, -1)
	
	for i = 1, nCount do AddItem(6, 1, 1512, 1, 0, 0) end
	Msg2Player("L�m th�nh c�ng " .. nCount .. " B�nh G� N��ng!")
end

function TienHanh_LamBanhHQ(nCount)
	if CheckNguyenLieuChung(nCount) == 0 then
		Msg2Player("Kh�ng �� " .. nCount .. " b� (B�t + ���ng + Tr�ng)!")
		return
	end
	if CalcEquiproomItemCount(6, 1, 1509, -1) < nCount then
		Msg2Player("Kh�ng �� " .. nCount .. " Th�t Heo!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	ConsumeNguyenLieuChung(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 1509, -1)
	
	for i = 1, nCount do AddItem(6, 1, 1513, 1, 0, 0) end
	Msg2Player("L�m th�nh c�ng " .. nCount .. " B�nh Heo Quay!")
end

function TienHanh_GhepHop(nCount)
	if CheckBonBanh(nCount) == 0 then
		Msg2Player("H�nh trang kh�ng c� �� " .. nCount .. " b� B�nh Trung Thu (4 V�)!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng �� gh�p ��!")
		return
	end
	
	ConsumeBonBanh(nCount)
	
	for i = 1, nCount do AddItem(6, 1, 1514, 1, 0, 0) end
	Msg2Player("Gh�p th�nh c�ng " .. nCount .. " H�p B�nh Trung Thu!")
end

-- ================= LOGIC B�N V?T PH?M (TR? TI?N) =================
function TienHanh_MuaHatSen(nCount)
	local nCost = nCount * 30000
	
	if GetCash() < nCost then
		Msg2Player("Ng��i kh�ng c� �� " .. (nCount * 3) .. " v�n l��ng!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	Pay(nCost)
	
	for i = 1, nCount do AddItem(6, 1, 1507, 1, 0, 0) end
	Msg2Player("Mua th�nh c�ng " .. nCount .. " T�i H�t Sen!")
end

function TienHanh_MuaThitGa(nCount)
	local nCost = nCount * 50000
	
	if GetCash() < nCost then
		Msg2Player("Ng��i kh�ng c� �� " .. (nCount * 5) .. " v�n l��ng!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	Pay(nCost)
	
	for i = 1, nCount do AddItem(6, 1, 1508, 1, 0, 0) end
	Msg2Player("Mua th�nh c�ng " .. nCount .. " T�i Th�t G�!")
end

function TienHanh_MuaThitHeo(nCount)
	if CalcEquiproomItemCount(4, 417, 1, -1) < nCount then
		Msg2Player("Ng��i kh�ng c� �� " .. nCount .. " Ti�n ��ng!")
		return
	end
	if CalcFreeItemCellCount() < 5 then
		Msg2Player("H�nh trang c�n �t nh�t 5 � tr�ng!")
		return
	end
	
	ConsumeEquiproomItem(nCount, 4, 417, 1, -1)
	
	for i = 1, nCount do AddItem(6, 1, 1509, 1, 0, 0) end
	Msg2Player("Mua th�nh c�ng " .. nCount .. " Th�t Heo b�ng Ti�n ��ng!")
end


-- ================= WRAPPERS G?I H�M =================
function LamBanhDX_1() TienHanh_LamBanhDX(1) end
function LamBanhDX_10() TienHanh_LamBanhDX(10) end
function LamBanhDX_50() TienHanh_LamBanhDX(50) end
function LamBanhDX_100() TienHanh_LamBanhDX(100) end

function LamBanhHS_1() TienHanh_LamBanhHS(1) end
function LamBanhHS_10() TienHanh_LamBanhHS(10) end
function LamBanhHS_50() TienHanh_LamBanhHS(50) end
function LamBanhHS_100() TienHanh_LamBanhHS(100) end

function LamBanhGN_1() TienHanh_LamBanhGN(1) end
function LamBanhGN_10() TienHanh_LamBanhGN(10) end
function LamBanhGN_50() TienHanh_LamBanhGN(50) end
function LamBanhGN_100() TienHanh_LamBanhGN(100) end

function LamBanhHQ_1() TienHanh_LamBanhHQ(1) end
function LamBanhHQ_10() TienHanh_LamBanhHQ(10) end
function LamBanhHQ_50() TienHanh_LamBanhHQ(50) end
function LamBanhHQ_100() TienHanh_LamBanhHQ(100) end

function GhepHop_1() TienHanh_GhepHop(1) end
function GhepHop_10() TienHanh_GhepHop(10) end
function GhepHop_50() TienHanh_GhepHop(50) end
function GhepHop_100() TienHanh_GhepHop(100) end

function MuaHS_1() TienHanh_MuaHatSen(1) end
function MuaHS_10() TienHanh_MuaHatSen(10) end
function MuaHS_50() TienHanh_MuaHatSen(50) end
function MuaHS_100() TienHanh_MuaHatSen(100) end

function MuaTG_1() TienHanh_MuaThitGa(1) end
function MuaTG_10() TienHanh_MuaThitGa(10) end
function MuaTG_50() TienHanh_MuaThitGa(50) end
function MuaTG_100() TienHanh_MuaThitGa(100) end

function MuaTH_1() TienHanh_MuaThitHeo(1) end
function MuaTH_10() TienHanh_MuaThitHeo(10) end
function MuaTH_50() TienHanh_MuaThitHeo(50) end
function MuaTH_100() TienHanh_MuaThitHeo(100) end

function KetThuc() end