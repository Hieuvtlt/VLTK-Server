Include("\\script\\lib\\common.lua")
Include("\\script\\task\\task_addplayerexp.lua")

function main(nItemIdx)
	local nMonth = tonumber(GetLocalDate("%m"))
	
	-- D?I S? 9 TH�NH S? 4 KHI CH?Y CH�NH TH?C
	if nMonth ~= 4 then
		Msg2Player("<color=red>B�nh Gi� T� �� h�t h�n s� d�ng!<color>") 
		return 1 -- Tr? v? 1 d? kh�ng b? m?t b�nh
	end
	
	local nG, nD, nP = GetItemProp(nItemIdx)
	local TSK_TONG_EXP = 1318 
	local TSK_NAM_EVENT = 1319
	local MAX_EXP = 1500000000
	local nYear = tonumber(GetLocalDate("%Y"))

	if GetTask(TSK_NAM_EVENT) ~= nYear then
		SetTask(TSK_TONG_EXP, 0) 
		SetTask(TSK_NAM_EVENT, nYear) 
	end

	local nExpDaNhan = GetTask(TSK_TONG_EXP)
	
	-- CH?N GI?I H?N EXP V� B?O TO�N B�NH
	if nExpDaNhan >= MAX_EXP then
		Msg2Player("<color=red>Th�ng n�y �� nh�n t�i �a 1.5 T� EXP, kh�ng th� �n th�m!<color>") 
		return 1 -- Tr? v? 1 d? gi? l?i b�nh trong h�nh trang
	end

	if nP == 1395 and CalcFreeItemCellCount() < 1 then
		Msg2Player("H�nh trang c�n �t nh�t 1 � tr�ng!") 
		return 1 -- Tr? v? 1 d? gi? l?i b�nh
	elseif nP == 1396 and CalcFreeItemCellCount() < 2 then
		Msg2Player("H�nh trang c�n �t nh�t 2 � tr�ng!") 
		return 1 -- Tr? v? 1 d? gi? l?i b�nh
	end
	
	-- Ch? khi qua h?t c�c v�ng ki?m tra tr�n, m?i ti?n h�nh tr? d�ng 1 c�i b�nh
	if ConsumeEquiproomItem(1, nG, nD, nP, -1) ~= 1 then
		Msg2Player("H� th�ng b�n, kh�ng th� s� d�ng!") 
		return 1
	end

	local nAddExp = 0
	local szName = ""

	if nP == 1395 then
		nAddExp = 5000000
		szName = "B�nh Chay ��c Bi�t"
		
		local nRand = random(1, 100)
		if nRand <= 25 then
			AddItem(6, 1, 5130, 1, 0, 0)
			Msg2Player("<color=yellow>Nh�n th�m C�ng Tr�ng L�nh!<color>")
		elseif nRand <= 50 then
			AddItem(6, 1, 5129, 1, 0, 0)
			Msg2Player("<color=yellow>Nh�n th�m Hu�n C�ng Ch��ng!<color>")
		elseif nRand <= 75 then
			AddItem(6, 1, 124, 1, 0, 0)
			Msg2Player("<color=yellow>Nh�n th�m Ph�c Duy�n L� (��i)!<color>")
		end
		
	elseif nP == 1396 then
		nAddExp = 3000000
		szName = "B�nh Chay Th��ng"
		AddItem(6, 0, 6, 1, 0, 0) 
		AddItem(6, 0, 3, 1, 0, 0) 
		Msg2Player("<color=yellow>Nh�n th�m Phi T�c v� ��i L�c Ho�n!<color>")
		
	elseif nP == 1397 then
		nAddExp = 1000000
		szName = "B�nh Chay Ch�a Ch�n"
	else
		return 1
	end

	if nExpDaNhan + nAddExp > MAX_EXP then nAddExp = MAX_EXP - nExpDaNhan end
	tl_addPlayerExp(nAddExp)
	SetTask(TSK_TONG_EXP, nExpDaNhan + nAddExp)
	
	Msg2Player("<color=pink>S� d�ng " .. szName .. " nh�n ���c " .. (nAddExp/10000) .. " v�n Kinh Nghi�m!<color>")
	return 1
end