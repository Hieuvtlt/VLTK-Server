Include("\\script\\lib\\common.lua")
Include("\\script\\dailogsys\\g_dialog.lua")
Include("\\script\\dailogsys\\dailogsay.lua")

function main()
	local szMsg = "Ta l� T�ng Qu�n S� Ki�n. Ng��i c� mu�n v�o th�ng b�ng test S� ki�n Th�ng 1 kh�ng?"
	local tbOpt = {
		{"Test S� ki�n Th�ng 1", KichHoat_Test},
		{"Tho�t", KetThuc}
	}
	CreateNewSayEx(szMsg, tbOpt)
	return 1
end

function KichHoat_Test()
	-- T?m b? check th�ng, �p g?i th?ng file Th�ng 1 d? test ch?c nang gh�p d?
	local szScriptPath = "script/sukien_nam/thang1/npc_thang1.lua"
	
	local bOK, err = pcall(dofile, szScriptPath)
	if not bOK then
		Msg2Player("<color=red>L�i load file: " .. err .. "<color>")
		return
	end
	
	if Menu_SuKien_Thang then
		Menu_SuKien_Thang()
	else
		Msg2Player("<color=red>L�i: Kh�ng t�m th�y h�m Menu_SuKien_Thang<color>")
	end
end

function KetThuc() end