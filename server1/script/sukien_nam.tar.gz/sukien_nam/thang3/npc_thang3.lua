Include("\\script\\lib\\common.lua")
Include("\\script\\dailogsys\\g_dialog.lua")
Include("\\script\\dailogsys\\dailogsay.lua")

function main()
	local nMonth = tonumber(GetLocalDate("%m"))
	if nMonth ~= 3 then
		local szMsg_Close = "<color=pink>Th� C�m Hoa:<color>\nM�a hoa th�ng 3 �� k�t th�c. H�n g�p l�i ��i hi�p v�o n�m sau!"
		CreateNewSayEx(szMsg_Close, {{"Tho�t", KetThuc}})
		return 1
	end

	local szMsg = "<color=pink>Th� C�m Hoa:<color>\nNg��i mu�n chu�n b� qu� t�ng g� cho th�ng 3 n�y?"
	local tbOpt = {
		{"Mua D�y C�t Hoa (B�ng V�n)", Menu_MuaDay},
		{"Mua Gi� ��ng Hoa (1 Ti�n ��ng)", Menu_MuaGio},
		{"G�i B� Hoa H�ng", Menu_GhepBo},
		{"C�m Gi� Hoa H�ng V�nh C�u", Menu_GhepGio},
		{"Tho�t", KetThuc}
	}
	CreateNewSayEx(szMsg, tbOpt)
	return 1
end

function Menu_SuKien_Thang3() main() end

function Menu_MuaDay()
	local tbOpt = {
		{"Mua 10 c�i (30 v�n)", function() MuaDay(10) end},
		{"Mua 50 c�i (150 v�n)", function() MuaDay(50) end},
		{"Mua 100 c�i (300 v�n)", function() MuaDay(100) end},
		{"Quay l�i", main}
	}
	CreateNewSayEx("1 D�y C�t Hoa gi� 3 v�n l��ng. Ch�n s� l��ng:", tbOpt)
end

function Menu_MuaGio()
	local tbOpt = {
		{"Mua 10 c�i (10 Ti�n ��ng)", function() MuaGio(10) end},
		{"Mua 50 c�i (50 Ti�n ��ng)", function() MuaGio(50) end},
		{"Mua 100 c�i (100 Ti�n ��ng)", function() MuaGio(100) end},
		{"Quay l�i", main}
	}
	CreateNewSayEx("1 Gi� ��ng Hoa gi� 1 Ti�n ��ng. Ch�n s� l��ng:", tbOpt)
end

function Menu_GhepBo()
	local tbOpt = {
		{"G�i 1 B�", function() GhepBo(1) end},
		{"G�i 10 B�", function() GhepBo(10) end},
		{"G�i 50 B�", function() GhepBo(50) end},
		{"G�i 100 B�", function() GhepBo(100) end},
		{"Quay l�i", main}
	}
	CreateNewSayEx("C�n: 4 lo�i Hoa H�ng v� 1 D�y C�t Hoa. Ch�n s� l��ng:", tbOpt)
end

function Menu_GhepGio()
	local tbOpt = {
		{"C�m 1 Gi�", function() GhepGio(1) end},
		{"C�m 10 Gi�", function() GhepGio(10) end},
		{"C�m 50 Gi�", function() GhepGio(50) end},
		{"C�m 100 Gi�", function() GhepGio(100) end},
		{"Quay l�i", main}
	}
	CreateNewSayEx("C�n: 4 lo�i Hoa H�ng v� 1 Gi� ��ng Hoa. Ch�n s� l��ng:", tbOpt)
end

function MuaDay(nCount)
	local nCost = nCount * 30000
	if GetCash() < nCost then
		Msg2Player("Kh�ng �� " .. (nCost/10000) .. " v�n l��ng!") return
	end
	if CalcFreeItemCellCount() < floor(nCount/10) + 1 then
		Msg2Player("H�nh trang kh�ng �� ch� tr�ng!") return
	end
	Pay(nCost)
	for i = 1, nCount do AddItem(6, 1, 5150, 1, 0, 0) end
	Msg2Player("Mua th�nh c�ng " .. nCount .. " D�y C�t Hoa!")
end

function MuaGio(nCount)
	if CalcEquiproomItemCount(4, 417, 1, -1) < nCount then
		Msg2Player("Kh�ng �� " .. nCount .. " Ti�n ��ng!") return
	end
	if CalcFreeItemCellCount() < floor(nCount/10) + 1 then
		Msg2Player("H�nh trang kh�ng �� ch� tr�ng!") return
	end
	ConsumeEquiproomItem(nCount, 4, 417, 1, -1)
	for i = 1, nCount do AddItem(6, 1, 5151, 1, 0, 0) end
	Msg2Player("Mua th�nh c�ng " .. nCount .. " Gi� ��ng Hoa!")
end

function CheckHoa(nCount)
	if CalcEquiproomItemCount(6, 1, 5146, -1) < nCount then return 0 end
	if CalcEquiproomItemCount(6, 1, 5147, -1) < nCount then return 0 end
	if CalcEquiproomItemCount(6, 1, 5148, -1) < nCount then return 0 end
	if CalcEquiproomItemCount(6, 1, 5149, -1) < nCount then return 0 end
	return 1
end

function ConsumeHoa(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 5146, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 5147, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 5148, -1)
	ConsumeEquiproomItem(nCount, 6, 1, 5149, -1)
end

function GhepBo(nCount)
	if CheckHoa(nCount) == 0 then Msg2Player("Kh�ng c� �� " .. nCount .. " b� 4 lo�i Hoa H�ng!") return end
	if CalcEquiproomItemCount(6, 1, 5150, -1) < nCount then Msg2Player("Kh�ng �� D�y C�t Hoa!") return end
	if CalcFreeItemCellCount() < 2 then Msg2Player("H�nh trang c�n �t nh�t 2 � tr�ng!") return end
	ConsumeHoa(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 5150, -1)
	for i = 1, nCount do AddItem(6, 1, 5152, 1, 0, 0) end
	Msg2Player("G�i th�nh c�ng " .. nCount .. " B� Hoa H�ng!")
end

function GhepGio(nCount)
	if CheckHoa(nCount) == 0 then Msg2Player("Kh�ng c� �� " .. nCount .. " b� 4 lo�i Hoa H�ng!") return end
	if CalcEquiproomItemCount(6, 1, 5151, -1) < nCount then Msg2Player("Kh�ng �� Gi� ��ng Hoa!") return end
	if CalcFreeItemCellCount() < 2 then Msg2Player("H�nh trang c�n �t nh�t 2 � tr�ng!") return end
	ConsumeHoa(nCount)
	ConsumeEquiproomItem(nCount, 6, 1, 5151, -1)
	for i = 1, nCount do AddItem(6, 1, 5153, 1, 0, 0) end
	Msg2Player("C�m th�nh c�ng " .. nCount .. " Gi� Hoa H�ng V�nh C�u!")
end

function KetThuc() end