Include("\\script\\lib\\common.lua")
Include("\\script\\dailogsys\\g_dialog.lua")
Include("\\script\\dailogsys\\dailogsay.lua")
Include("\\script\\lib\\awardtemplet.lua")
Include("\\script\\task\\task_addplayerexp.lua")

-- ================= B?NG THU?NG B� HOA (GI? NGUY�N) =================
tb_QuaBoHoa = {
	[1]  = {szName="T� Th�y Tinh", tbProp={4, 239, 1, 1, 0, 0}, nRate=0},
	[2]  = {szName="Lam Th�y Tinh", tbProp={4, 238, 1, 1, 0, 0}, nRate=0},
	[3]  = {szName="L�c Th�y Tinh", tbProp={4, 240, 1, 1, 0, 0}, nRate=0},
	[4]  = {szName="Tinh H�ng B�o Th�ch", tbProp={4, 353, 1, 1, 0, 0}, nRate=0},
	[5]  = {szName="Hu�n C�ng Ch��ng", tbProp={6, 1, 5129, 1, 0, 0}, nRate=25},
	[6]  = {szName="C�ng Tr�ng L�nh", tbProp={6, 1, 5130, 1, 0, 0}, nRate=25},
	[7]  = {szName="Huy�n tinh kho�ng th�ch c�p 3", tbProp={6, 1, 147, 3, 0, 0}, nRate=0},
	[8]  = {szName="Huy�n tinh kho�ng th�ch c�p 4", tbProp={6, 1, 147, 4, 0, 0}, nRate=0},
	[9]  = {szName="Huy�n tinh kho�ng th�ch c�p 5", tbProp={6, 1, 147, 5, 0, 0}, nRate=0},
	[10] = {szName="V�t ph�m ng�u nhi�n 1", tbProp={6, 1, 33, 1, 0, 0}, nRate=0}, 
	[11] = {szName="V�t ph�m ng�u nhi�n 2", tbProp={6, 1, 45, 1, 0, 0}, nRate=0}, 
	[12] = {szName="M�nh trang b� Ho�ng Kim", tbProp={6, 1, 5128, 1, 0, 0}, nRate=0},
	[13] = {szName="Phi T�c Ho�n", tbProp={6, 0, 6, 1, 0, 0}, nRate=50},
	[14] = {szName="��i L�c Ho�n", tbProp={6, 0, 3, 1, 0, 0}, nRate=50},
	[15] = {szName="Ph�c Duy�n L� (��i)", tbProp={6, 1, 124, 1, 0, 0}, nRate=25}
}

-- ================= B?NG THU?NG GI? HOA (51 ITEM T�CH L? C? D?NH) =================
tb_QuaGioHoa = {
	[1]  = {szName="Kim Quang B�t K�nh Chi M�ng", nQuality=1, tbProp={0, 197}, nRate = 0.02},
	[2]  = {szName="Kim Quang Nh� �i�n Chi H�n", nQuality=1, tbProp={0, 202}, nRate = 0.02},
	[3]  = {szName="Thi�n S�n Tuy�t Li�n", tbProp={6,1,1431,1,0,0}, nRate = 0.01},
	[4]  = {szName="T� Th�y Tinh", tbProp = {4, 239, 1, 1, 0, 0}, nRate = 3},
	[5]  = {szName="Lam Th�y Tinh", tbProp = {4, 238, 1, 1, 0, 0}, nRate = 2},
	[6]  = {szName="L�c Th�y Tinh", tbProp = {4, 240, 1, 1, 0, 0}, nRate = 2},
	[7]  = {szName="Tinh H�ng B�o Th�ch", tbProp = {4, 353, 1, 1, 0, 0}, nRate = 1},
	[8]  = {szName="Hu�n C�ng Ch��ng", tbProp = {6, 1, 5129, 1, 0, 0}, nRate = 5},
	[9]  = {szName="C�ng Tr�ng L�nh", tbProp = {6, 1, 5130, 1, 0, 0}, nRate = 5},
	[10] = {szName="Huy�n tinh kho�ng th�ch c�p 3", tbProp = {6, 1, 147, 3, 0, 0}, nRate = 20},
	[11] = {szName="Huy�n tinh kho�ng th�ch c�p 4", tbProp = {6, 1, 147, 4, 0, 0}, nRate = 15},
	[12] = {szName="Huy�n tinh kho�ng th�ch c�p 5", tbProp = {6, 1, 147, 5, 0, 0}, nRate = 10},
	[13] = {szName="Huy�n tinh kho�ng th�ch c�p 6", tbProp = {6, 1, 147, 6, 0, 0}, nRate = 5},
	[14] = {szName="Huy�n tinh kho�ng th�ch c�p 7", tbProp = {6, 1, 147, 7, 0, 0}, nRate = 0.1},
	[15] = {szName="Huy�n tinh kho�ng th�ch c�p 8", tbProp = {6, 1, 147, 8, 0, 0}, nRate = 0.05},
	[16] = {szName="Phi T�c Ho�n", tbProp = {6, 0, 6, 1, 0, 0}, nRate = 5},
	[17] = {szName="��i L�c Ho�n", tbProp = {6, 0, 3, 1, 0, 0}, nRate = 5},
	[18] = {szName="Ph�c Duy�n L� (��i)", tbProp = {6, 1, 124, 1, 0, 0}, nRate = 5},
	[19] = {szName="Kim Quang Tr�ch Tinh Ho�n", nQuality=1, tbProp={0, 194}, nRate = 0.02},
	[20] = {szName="Kim Quang ���ng Ngh� Gi�p", nQuality=1, tbProp={0, 195}, nRate = 0.02},
	[21] = {szName="Kim Quang L�c Phi Th�y H�a Th�n Ph�", nQuality=1, tbProp={0, 196}, nRate = 0.02},
	[22] = {szName="Kim Quang B�ch Kim Y�u ��i", nQuality=1, tbProp={0, 198}, nRate = 0.02},
	[23] = {szName="Kim Quang Thi�n T�m H� Uy�n", nQuality=1, tbProp={0, 199}, nRate = 0.02},
	[24] = {szName="Kim Quang Ng� S�c Ng�c B�i", nQuality=1, tbProp={0, 200}, nRate = 0.02},
	[25] = {szName="Kim Quang Thi�n T�m Ngoa", nQuality=1, tbProp={0, 201}, nRate = 0.02},
	[26] = {szName="V� L�m M�t T�ch", tbProp={6, 1, 26, 1, 0, 0}, nRate = 0.5},
	[27] = {szName="T�y T�y Kinh", tbProp={6, 1, 22, 1, 0, 0}, nRate = 0.5},
	[28] = {szName="C�ng Nguy�t Qu� Dung", tbProp={6, 1, 128, 1, 0, 0}, nRate = 0.5},
	[29] = {szName="Ph�ng Nguy�t Qu� Dung", tbProp={6, 1, 127, 1, 0, 0}, nRate = 0.5},
	
	-- B? D?NG S�T
	[30] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 143}, nRate = 0.005},
	[31] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 144}, nRate = 0.005},
	[32] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 145}, nRate = 0.005},
	[33] = {szName="Trang b� ��ng S�t", nQuality=1, tbProp={0, 146}, nRate = 0.005},
	
	-- B? D?NH QU?C & AN BANG
	[34] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 159}, nRate = 0.004},
	[35] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 160}, nRate = 0.004},
	[36] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 161}, nRate = 0.004},
	[37] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 162}, nRate = 0.004},
	[38] = {szName="Trang b� ��nh Qu�c", nQuality=1, tbProp={0, 163}, nRate = 0.004},
	[39] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 164}, nRate = 0.004},
	[40] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 165}, nRate = 0.004},
	[41] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 166}, nRate = 0.004},
	[42] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 167}, nRate = 0.004},
	[43] = {szName="Trang b� An Bang", nQuality=1, tbProp={0, 168}, nRate = 0.004},
	
	-- B? NHU T�NH & HI?P C?T
	[44] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 186}, nRate = 0.005},
	[45] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 187}, nRate = 0.005},
	[46] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 188}, nRate = 0.005},
	[47] = {szName="Trang b� Nhu T�nh", nQuality=1, tbProp={0, 189}, nRate = 0.005},
	[48] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 190}, nRate = 0.005},
	[49] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 191}, nRate = 0.005},
	[50] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 192}, nRate = 0.005},
	[51] = {szName="Trang b� Hi�p C�t", nQuality=1, tbProp={0, 193}, nRate = 0.005},
}

-- T? D?NG CH�N 119 D�NG HO�NG KIM M�N PH�I (5314 -> 5432) CHO GI? HOA
local nIndex = 52
for nId = 5314, 5432 do
	tb_QuaGioHoa[nIndex] = {szName="Trang b� Ho�ng Kim M�n Ph�i", nQuality=1, tbProp={0, nId}, nRate = 0.00002}
	nIndex = nIndex + 1
end

function main()
	local nMonth = tonumber(GetLocalDate("%m"))
	if nMonth ~= 5 then
		CreateNewSayEx("<color=pink>S� Gi� T�nh Y�u:<color>\nTh�ng 3 �� qua, c�m �n t�nh c�m c�a c�c v�!", {{"Tho�t", KetThuc}})
		return 1
	end

	local szMsg = "<color=pink>S� Gi� T�nh Y�u:<color>\nH�y trao nh�ng b� hoa v� gi� hoa t��i th�m nh�t, ta s� t�ng l�i cho b�n kinh nghi�m v� s� may m�n!"
	local tbOpt = {
		{"T�ng 1 B� Hoa (3 tr EXP)", function() NopHoa(1, 1) end},
		{"T�ng 10 B� Hoa", function() NopHoa(1, 10) end},
		{"T�ng 1 Gi� Hoa (5 tr EXP)", function() NopHoa(2, 1) end},
		{"T�ng 10 Gi� Hoa", function() NopHoa(2, 10) end},
		{"Tho�t", KetThuc}
	}
	CreateNewSayEx(szMsg, tbOpt)
	return 1
end

function NopHoa(nType, nCount)
	local TSK_TONG_EXP = 1314
	local TSK_COUNT_BOHOA = 1317
	local TSK_NAM_EVENT = 1315
	local MAX_EXP = 1500000000
	local nYear = tonumber(GetLocalDate("%Y"))

	if GetTask(TSK_NAM_EVENT) ~= nYear then
		SetTask(TSK_TONG_EXP, 0) 
		SetTask(TSK_COUNT_BOHOA, 0) 
		SetTask(TSK_NAM_EVENT, nYear) 
	end

	local nExpDaNhan = GetTask(TSK_TONG_EXP)
	if nExpDaNhan >= MAX_EXP then
		Msg2Player("<color=red>Ng��i �� nh�n t�i �a 1.5 T� EXP trong th�ng n�y!<color>") return
	end

	local nItemId, nExpPerItem, szTitle
	local nNeedSpace = nCount + 5
	
	if nType == 1 then
		nItemId = 5152
		nExpPerItem = 3000000
		szTitle = "B� Hoa H�ng"
	else
		nItemId = 5153
		nExpPerItem = 5000000
		szTitle = "Gi� Hoa V�nh C�u"
	end

	if CalcFreeItemCellCount() < nNeedSpace then
		Msg2Player("H�nh trang c�n �t nh�t " .. nNeedSpace .. " � tr�ng �� nh�n th��ng!") return
	end

	if CalcEquiproomItemCount(6, 1, nItemId, -1) < nCount then
		Msg2Player("H�nh trang kh�ng c� �� " .. nCount .. " " .. szTitle .. "!") return
	end

	local nTotalAdd = nExpPerItem * nCount
	if nExpDaNhan + nTotalAdd > MAX_EXP then
		Msg2Player("<color=red>S� l��ng " .. szTitle .. " n�y s� v��t qu� 1.5 T� EXP. H�y gi�m b�t!<color>") return
	end

	ConsumeEquiproomItem(nCount, 6, 1, nItemId, -1)
	tl_addPlayerExp(nTotalAdd)
	SetTask(TSK_TONG_EXP, nExpDaNhan + nTotalAdd)
	
	local nOldCount = GetTask(TSK_COUNT_BOHOA)
	local nNewCount = nOldCount

	-- X? l� tr? thu?ng t�ch bi?t cho 2 lo?i hoa
	for i = 1, nCount do
		if nType == 1 then
			nNewCount = nNewCount + 1
			-- B� Hoa v?n d�ng b?ng cu, sinh random ? v? tr� 10 v� 11
			tb_QuaBoHoa[10].tbProp[3] = random(33, 43)
			tb_QuaBoHoa[11].tbProp[3] = random(45, 62)
			tbAwardTemplet:GiveAwardByList(tb_QuaBoHoa, szTitle)
		else
			-- Gi? Hoa b?c ph?n thu?ng t? b?ng m?i tb_QuaGioHoa
			tbAwardTemplet:GiveAwardByList(tb_QuaGioHoa, szTitle)
		end
	end

	-- X? l� thu?ng m?c 100 B� Hoa (Ch? t�nh cho Lo?i 1)
	if nType == 1 then
		SetTask(TSK_COUNT_BOHOA, nNewCount)
		local nMilestone100 = floor(nNewCount / 100) - floor(nOldCount / 100)
		if nMilestone100 > 0 then
			for m = 1, nMilestone100 do
				AddItem(6, 1, 5128, 1, 0, 0)
				Msg2Player("<color=yellow>Ch�c m�ng! ��t m�c 100 B� Hoa, nh�n 1 M�nh Ho�ng Kim!<color>")
			end
		end
	end
	
	Msg2Player("<color=pink>T�ng th�nh c�ng " .. nCount .. " " .. szTitle .. ", nh�n ���c " .. (nTotalAdd/10000) .. " v�n Kinh Nghi�m!<color>")
end

function KetThuc() end