Include("\\script\\lib\\composeex.lua")
Include("\\script\\misc\\eventsys\\type\\npc.lua")
Include("\\script\\lib\\log.lua")

tbHanCheRefineEquip = tbActivityCompose:new()

tbHanCheRefineList = 
{
	[1]= {szName="Trang B� HKMP", nWidth = 2, nHeight = 1, nFreeItemCellLimit = 1},
}

function tbHanCheRefineEquip:ComposeGiveUI()
	local szTitle = format("  %-15s\t%s", "Trang b� HKMP", "Tr�ng Luy�n \nTrang b� HKMP")
	local strDesc = "Ch� c�n b� trang b� HKMP v�o, kh�ng c�n nguy�n li�u."
	g_GiveItemUI(szTitle, strDesc, {self.GiveUIOk, {self}}, nil, self.bAccessBindItem)
end

function tbHanCheRefineEquip:Compose(nComposeCount)
	nComposeCount = nComposeCount or 1
	
	if type(self.tbFormula.pLimitFun) == "function" then
		if self.tbFormula:pLimitFun(nComposeCount) ~= 1 then
			return 0
		end
	end
	
	local tbRoomItems = self:GetRoomItems(self.nRoomType)
	local tbGoldEquip = nil
	local nEquType = 0
	local nEqIndex = 0
	local nOldItemIndex = nil
	local tbEquip_Hkmp1 = nil
	
	for i = 1, getn(tbRoomItems) do 
		local nItemQuality = GetItemQuality(tbRoomItems[i])
		
		if nItemQuality == 1 then
			nEqIndex = GetGlodEqIndex(tbRoomItems[i])
			tbEquip_Hkmp1 = {
				[1] = {
					{szName = "Trang b� HKMP", tbProp = {0, nEqIndex}, nQuality = 1, nCount = 1, nRate = 4.5},
				},
			}
			
			if nEqIndex >= 1 and nEqIndex <= 1000 then
				local nBindState = GetItemBindState(tbRoomItems[i])
				if nBindState ~= 0 then
					Say("Trang b� c�a ng��i �ang trong tr�ng th�i kh�a, kh�ng th� tr�ng luy�n.")
					return 0
				end
				
				local nG, _, _ = GetItemProp(tbRoomItems[i])
				if nG == 7 then
					Say("Trang b� c�a ng��i �� b� h� h�i kh�ng th� tr�ng luy�n.")
					return 0
				end
				
				nEquType = 1
				tbGoldEquip = {0, nEqIndex}
				nOldItemIndex = tbRoomItems[i]
				break
			end
		end	
	end
	
	if tbGoldEquip == nil then
		Say("Ng��i ch�a ��t trang b� HKMP n�o v�o ��y c�.")
		return 0	
	end
	
	RemoveItemByIndex(nOldItemIndex)	
	
	local tbProduct = tbEquip_Hkmp1[1][1]
	tbAwardTemplet:GiveAwardByList(tbProduct, self.szLogTitle, nComposeCount)
	Msg2SubWorld("<color=cyan>Ch�c m�ng ��i hi�p <color=green>"..GetName().."<color=yellow> Tr�ng Luy�n Th�nh C�ng <color=green>Trang B� HKMP!")
	
	if type(self.tbFormula.pProductFun) == "function" then
		self.tbFormula:pProductFun(nComposeCount)
	end
	return 1
end

function refine_HanChe()
	local strDesc = "<npc>��t <color=yellow>trang b� HKMP<color> mu�n tr�ng luy�n v�o ph�a d��i. <color=green>Kh�ng c�n nguy�n li�u, lu�n th�nh c�ng!<color>"
	local tbOpt = {}
	local tbMate = {
		tbMaterial = {
			{szName = "Trang b� HKMP", tbProp = {0, {1,904}}, nQuality = 1},
		},
		tbProduct = {szName = "Trang b� HKMP", tbProp = {0, {1,904}}},
	}
	local p = tbHanCheRefineEquip:new(tbMate, "HanCheRefineEquip", INVENTORY_ROOM.room_giveitem)
	tinsert(tbOpt, {"Tr�ng luy�n trang b� Tr�n Bang Chi B�o", p.ComposeGiveUI, {p}})
	tinsert(tbOpt, {"H�y b�"})
	CreateNewSayEx(strDesc, tbOpt)
end