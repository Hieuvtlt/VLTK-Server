EQUIPBLUE_LIST = 
{
	100000,
	{
		{G=0,D=0,P=0,nrate=8,szname="Huy�n Thi�t Ki�m"},
		{G=0,D=0,P=1,nrate=4,szname="��i Phong �ao"},
		{G=0,D=0,P=2,nrate=8,szname="Kim C� B�ng"},
		{G=0,D=0,P=3,nrate=15,szname="Ph� Thi�n K�ch"},
		{G=0,D=0,P=4,nrate=15,szname="Ph� Thi�n ch�y"},
		{G=0,D=0,P=5,nrate=15,szname="Th�n Nh�t Tr�m"},
		{G=0,D=0,P=6,nrate=15,szname="Li�t Thi�n Tri�n Th�"},
		{G=0,D=1,P=0,nrate=15,szname="B� V��ng Ti�u"},
		{G=0,D=1,P=1,nrate=15,szname="To�i Nguy�t �ao"},
		{G=0,D=1,P=2,nrate=5,szname="Kh�ng T��c Linh"},
	}
}


tbMaterial_List = {
	{szName="Lam Thu� Tinh", tbProp={4,238,1,-1},nCount = 1},
	{szName="T� Thu� Tinh", tbProp={4,239,1,-1},nCount = 1},
	{szName="L�c Thu� Tinh", tbProp={4,240,1,-1},nCount = 1},
	{szName="Th�ch Chuy�n H�a", tbProp={6,1,5286,1,0,0,-10},nCount = 10},
	{szName="Th�n b� kho�ng th�ch",tbProp={6,1,398,1,0,0,-2},nCount=2},
	{szName="Ph�c Duy�n L� ��i", tbProp={6,1,124,1,0,0,-10},nCount=10},
}

nPractice_Fees = 500000;
