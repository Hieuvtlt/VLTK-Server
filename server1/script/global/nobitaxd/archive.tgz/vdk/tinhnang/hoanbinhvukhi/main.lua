IncludeLib("TASKSYS");
Include("\\script\\lib\\gb_taskfuncs.lua")
Include("\\script\\lib\\composeex.lua")
Include("\\script\\dailogsys\\dailogsay.lua")
Include("\\script\\lib\\progressbar.lua")
Include("\\script\\global\\nobitaxd\\vdk\\tinhnang\\hoanbinhvukhi\\head.lua")
function myplayersex()
if GetSex() == 1 then return "N� hi�p"; else return "��i hi�p"; end
end

function mainhoandoi()
	dofile("script/global/nobitaxd/vdk/tinhnang/hoanbinhvukhi/main.lua")
		local tbOpt = {
			{"Ta mu�n Ho�n ��i Binh Kh�.",weaponswap},
			{"K�t th�c d�i tho�i",No},
		}
	CreateNewSayEx("<npc><color=green>ta ��y c� nhi�u s� l�a ch�n cho "..myplayersex().." , ng��i mu�n l�m g� ?<color>", tbOpt)
end

function WriteLogAll(szPath, szFile, szMsg)
	local logDir = "log/"
	local check = io.open(logDir.."test.tmp", "w")
	if not check then
		os.execute("mkdir " .. logDir)
	else
		check:close()
		os.remove(logDir.."test.tmp")
	end

	local filePath = logDir.."hoanbinhvukhi_"..date("%d_%m_%Y")..".txt"
	local file = io.open(filePath, "a+")
	if file then
		file:write(string.format("[%s] %s\n", date("%Y-%m-%d %H:%M:%S"), szMsg))
		file:close()
	else
		Msg2Player("<color=red>Kh�ng th� ghi log! H�y ki�m tra quy�n th� m�c /log/<color>")
	end
end

function weaponswap()
	local tbMaterial = tbMaterial_List;
	local szTitle = format("Ho�n Binh V� Kh�")
	local szContent = "��t v� kh� c�n ��i v�o :";
	szContent = szContent.."<enter>------------------";
	szContent = szContent.."<enter>Nguy�n li�u c�n :";
	szContent = format("%s<enter>%-20s  %s", szContent, "V�t ph�m", "S� l��ng")	
	for i = 1, getn(tbMaterial_List) do
		szContent = format("%s<enter>%-20s  %s", szContent, tbMaterial_List[i].szName, tbMaterial_List[i].nCount)
	end
	if nPractice_Fees > 0 then 
		szContent = format("%s<enter>%-20s  %s", szContent, "V�n l��ng", floor(nPractice_Fees/10000))
		g_GiveItemUI(szTitle, szContent, {weaponswap_action})
	end
	
end

function weaponswap_action(nCount)
	if nCount ~= 1 then
		Talk(1, "", "Ch� ���c b� 1 m�n v� kh� c�n ho�n ��i")
		return
	end
	nItemIndex = GetGiveItemUnit(1)
	local nEquipVer = ITEM_GetItemVersion(nItemIndex)
	local nQuality = GetItemQuality(nItemIndex)
	local nGenre, nDetailType, nParticular, nLevel, nSeries, nLuck = GetItemProp(nItemIndex)
	local nEquipRandSeed = ITEM_GetItemRandSeed(nItemIndex)
	local arynMagLvl = GetItemAllParams(nItemIndex)	
	local nOldItemIndex = GetItemName(nItemIndex)
	if (nQuality ~= 0) then 
		Talk (1,"","Trang b� ��t v�o kh�ng ph�i <color=blue>Trang B� Xanh") 
		return 
	end
	if nGenre ~= 0 or nDetailType >= 2 then 
		Talk(1,"","Trang b� ng��i b� v�o kh�ng ph�i l� <color=red>V� Kh�<color>!!!") 
		return 
	end

	if (GetCash() < nPractice_Fees) then
		Say(format("R�t ti�c! B�n kh�ng c� �� <color=yellow>%s l��ng<color>!",nPractice_Fees));
		return
	end;
	for i = 1, getn(tbMaterial_List) do
		local nCheck = CalcEquiproomItemCount(tbMaterial_List[i].tbProp[1],tbMaterial_List[i].tbProp[2],tbMaterial_List[i].tbProp[3],tbMaterial_List[i].tbProp[4])
		if (nCheck < tbMaterial_List[i].nCount) then
			Say(""..myplayersex().." mang thi�u <color=red>"..(tbMaterial_List[i].nCount-nCheck).."<color> <color=yellow>"..tbMaterial_List[i].szName.."<color>!")
			return
		end;
	end;
	
	
	for i = 1, getn(tbMaterial_List) do
		ConsumeEquiproomItem(tbMaterial_List[i].nCount,tbMaterial_List[i].tbProp[1],tbMaterial_List[i].tbProp[2],tbMaterial_List[i].tbProp[3],tbMaterial_List[i].tbProp[4]);
	end;
	RemoveItemByIndex(nItemIndex)
	if nPractice_Fees > 0 then
		Pay(nPractice_Fees);
	end
	local nrate = random(1,EQUIPBLUE_LIST[1]);
	local nsum = 0
	for nkey,nitem in EQUIPBLUE_LIST[2] do
		nsum = nsum + (nitem["nrate"] * 1000)
		if (nsum > nrate) then
			local g = nitem["G"];
			local d = nitem["D"];
			local p = nitem["P"];
			local nNewItemIndex = AddItemEx(nEquipVer,nEquipRandSeed,nQuality,g,d,p,nLevel,nSeries,nLuck,arynMagLvl[1],arynMagLvl[2],arynMagLvl[3],arynMagLvl[4],arynMagLvl[5],arynMagLvl[6])
			local msg = format("<color=yellow>Ch�c m�ng "..myplayersex().." �� Ho�n Binh th�nh c�ng t� <color=blue><%s><color> Th�nh <color=blue><%s><color>.", nOldItemIndex, GetItemName(nNewItemIndex) )
			Msg2Player(msg)
			return 0
		end
	end
end























