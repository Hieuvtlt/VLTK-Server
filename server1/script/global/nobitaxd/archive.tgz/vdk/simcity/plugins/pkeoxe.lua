Include("\\script\\lib\\timerlist.lua")

SimCityKeoXe = {
	ALLXE = {

		{ 1355, 1356, 523,  1358, 513,  1360, 1361, 1362, 511,  1364, },
		{ 566,  739,  567,  568,  741,  1366, 742,  582,  743,  1365, 740, },
		{ 744,  745,  583,  565,  563,  748,  746,  562,  1367, 1368, 747, },
		{ 1194, 1193, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1231, },
		{ 1875, 1874, 1873, },
		{ 1466, 1437, 1479, 1438, },
	},

	collections = {},
	collections_knownPoint = {}

}


function createTaskSayKeoxe()
	local tbOpt = {}
	local nSettingIdx = 103
	local nActionId = 1
	tinsert(tbOpt, 1, "<dec><link=image[0,14]:#npcspr:?NPCSID="..tostring(nSettingIdx).."?ACTION="..tostring(nActionId)..">V� K�:<link> Nh�n sinh nh� m�ng, tr��ng l�u v� t�n, g�p g� ch� l� tho�ng qua");
	return tbOpt
end

function SimCityKeoXe:taoNV(id, camp, mapID, map, nt, theosau, capHP, extraConfig)
	local name = GetName()
	local rank = 1

	local tbNpc = {

		szName = SimCityNPCInfo:generateName(),

		nNpcId = id,   -- required, main char ID
		nMapId = mapID, -- required, map
		camp = camp,   -- optional, camp

		walkMode = "random", -- optional: random, keoxe, or 1 for formation
		walkVar = 2,   -- random walk of radius of 4*2


		noStop = 1,          -- optional: cannot pause any stop (otherwise 90% walk 10% stop)
		leaveFightWhenNoEnemy = 5, -- optional: leave fight instantly after no enemy, otherwise there's waiting period

		noRevive = 0,        -- optional: 0: keep reviving, 1: dead

		CHANCE_ATTACK_PLAYER = 1, -- co hoi tan cong nguoi choi neu di ngang qua
		CHANCE_ATTACK_NPC = 1, -- co hoi bat chien dau khi thay NPC khac phe
		CHANCE_JOIN_FIGHT = 1, -- co hoi tang cong NPC neu di ngang qua NPC danh nhau
		RADIUS_FIGHT_PLAYER = 15, -- scan for player around and randomly attack
		RADIUS_FIGHT_NPC = 10, -- scan for NPC around and start randomly attack,
		RADIUS_FIGHT_SCAN = 10, -- scan for fight around and join/leave fight it
 
		kind = 0,            -- quai mode
		TIME_FIGHTING_minTs = 1800,
		TIME_FIGHTING_maxTs = 3000,
		TIME_RESTING_minTs = 0,
		TIME_RESTING_maxTs = 1,


		ngoaitrang = nt or 0,

		childrenSetup = theosau or nil,
		childrenCheckDistance = (theosau and 8) or nil, -- force distance check for child

		playerID = name,
		capHP = capHP,
		role = "keoxe",
		mode = "keoxe"
	};
	if extraConfig then
		for k, v in extraConfig do
			tbNpc[k] = v
		end
	end
	local nListId = SimTheoSau:New(tbNpc);

	if not self.collections[name] then
		self.collections[name] = {}
	end

	if nListId > 0 then
		tinsert(self.collections[name], nListId)
	end

	return nListId
end

function SimCityKeoXe:nv_tudo_xe(capHP)
	local forCamp = GetCurCamp()
	local pW, pX, pY = GetWorldPos()
	local pool = SimCityNPCInfo:getPoolByCap(capHP)

	-- 10 con theo sau
	for i = 1, 10 do
		local pid = pool[random(1, getn(pool))]


		while SimCityNPCInfo:notFightingChar(pid) == 1 do
			pid = pool[random(1, getn(pool))]
		end

		local children = {}
		self:taoNV(pid, forCamp, pW, {}, 1, children, capHP)
	end
end

function SimCityKeoXe:goiAnhHungThiepNgoaiTrang()
	local tbSay = createTaskSayKeoxe()


	tinsert(tbSay, "�� t� tinh anh/#SimCityKeoXe:nv_tudo_xe(1)")
	tinsert(tbSay, "Cao th� nh�t l�u/#SimCityKeoXe:nv_tudo_xe(2)")
	tinsert(tbSay, "Tuy�n ��nh cao th�/#SimCityKeoXe:nv_tudo_xe(3)")
	tinsert(tbSay, "V� l�m ch� t�n/#SimCityKeoXe:nv_tudo_xe(4)")
	tinsert(tbSay, "Quay l�i./#SimCityKeoXe:mainMenu()")
	tinsert(tbSay, "K�t th�c ��i tho�i./no")
	CreateTaskSay(tbSay)
	return 1
end

function SimCityKeoXe:goiAnhHungThiep()
	local tbSay = createTaskSayKeoxe()

	-- Chon xe nao
	tinsert(tbSay, "M� t�t c�/#SimCityKeoXe:taonhanhnhom_confirm(0)")

	for i = 1, getn(self.ALLXE) do
		tinsert(tbSay, format("M� nh�m %d/#SimCityKeoXe:taonhanhnhom_confirm(%d)", i, i))
	end

	tinsert(tbSay, "Quay l�i./#SimCityKeoXe:mainMenu()")
	tinsert(tbSay, "K�t th�c ��i tho�i./no")
	CreateTaskSay(tbSay)
	return 1
end

function SimCityKeoXe:taonhanhnhom_confirm(mode)
	local ALLXE = self.ALLXE
	-- 0 = all in
	if (mode == 0) then
		for i = 1, getn(ALLXE) do
			self:tao1xe(ALLXE[i], ngoaitrang)
		end
		-- Mode 0: full 5 xe
	elseif (mode > 0 and mode <= getn(ALLXE)) then
		self:tao1xe(ALLXE[mode], ngoaitrang)
	end
end

function SimCityKeoXe:tao1xe(data)
	local forCamp = GetCurCamp()
	local pW, pX, pY = GetWorldPos()

	-- 10 con theo sau
	for i = 1, getn(data) do
		local pid = data[i]
		local children = {}
		self:taoNV(pid, forCamp, pW, {}, 0, children, 0)
	end
end

function SimCityKeoXe:ketgiaoNgauNhien()
	local tbSay = createTaskSayKeoxe()
	local phai = random(1, 10)
	local ten = SimCityNPCInfo:generateName()
	local gen = random(1,2)
	if phai == 2 then 
		gen = 1
	elseif	phai == 7 or phai == 8 then
		gen = 2
	end 
	self.randomName = {ten}
	SimCityKeoXe:taoBangHuu(phai, gen, 1)
	return 1
end

function SimCityKeoXe:ketgiaoPhai(phai)
	local tbSay = createTaskSayKeoxe()	
	if phai == 0 then
		tinsert(tbSay, "Giang h� l�ng t�/#SimCityKeoXe:ketgiaoNgauNhien()")
		tinsert(tbSay, "Thi�n V��ng Bang/#SimCityKeoXe:ketgiaoPhai(1)")
		tinsert(tbSay, "Thi�u L�m/#SimCityKeoXe:ketgiaoPhai(2)")
		tinsert(tbSay, "V� �ang/#SimCityKeoXe:ketgiaoPhai(3)")
		tinsert(tbSay, "C�n L�n/#SimCityKeoXe:ketgiaoPhai(4)")
		tinsert(tbSay, "���ng M�n/#SimCityKeoXe:ketgiaoPhai(5)")
		tinsert(tbSay, "Ng� ��c/#SimCityKeoXe:ketgiaoPhai(6)")
		tinsert(tbSay, "Nga Mi/#SimCityKeoXe:ketgiaoPhai(7)")
		tinsert(tbSay, "Th�y Y�n/#SimCityKeoXe:ketgiaoPhai(8)")
		tinsert(tbSay, "C�i Bang/#SimCityKeoXe:ketgiaoPhai(9)")
		tinsert(tbSay, "Thi�n Nh�n/#SimCityKeoXe:ketgiaoPhai(10)")				
		tinsert(tbSay, "K�t th�c ��i tho�i./no")
	else
		self.randomName = {}
		for i=1, 5 do
			self.randomName[i] = SimCityNPCInfo:generateName()
			local gen = random(1,2)
			if phai == 2 then 
				gen = 1
			elseif	phai == 7 or phai == 8 then
				gen = 2
			end

			local gioiTinh = "Nam"
			if gen == 2 then
				gioiTinh = "N�"
			end

			
			local ten = self.randomName[i]

			tinsert(tbSay, format("%s (%s)/#SimCityKeoXe:taoBangHuu(%s, %d, %s)", ten, gioiTinh, phai, gen, i))
		end
		tinsert(tbSay, format("T�m th�m/#SimCityKeoXe:ketgiaoPhai(%d)", phai))
		tinsert(tbSay, format("Quay l�i/#SimCityKeoXe:ketgiaoPhai(%d)", 0))
		tinsert(tbSay, "K�t th�c ��i tho�i./no")

	end
	
	CreateTaskSay(tbSay)
	return 1
end 

function SimCityKeoXe:taoBangHuu(phai, gen, tenIndex)
	local ten = self.randomName[tenIndex]
	local forCamp = GetCurCamp()
	local pW, pX, pY = GetWorldPos()
	local tenPhai = "thienvuong"
	if phai == 2 then
		tenPhai = "thieulam"
	elseif phai == 3 then
		tenPhai = "vodang"
	elseif phai == 4 then
		tenPhai = "conlon"
	elseif phai == 5 then
		tenPhai = "duongmon"
	elseif phai == 6 then
		tenPhai = "ngudoc"
	elseif phai == 7 then
		tenPhai = "ngami"
	elseif phai == 8 then
		tenPhai = "thuyyen"
	elseif phai == 9 then
		tenPhai = "caibang"
	elseif phai == 10 then
		tenPhai = "thiennhan"				
	end



	local pool = {}
	if SimCityPhai[tenPhai] then
		pool = getObjectKeys(SimCityPhai[tenPhai].knownIds)
		id = pool[random(1, getn(pool))]
		local realGen = -2
		if gen == 1 then
			realGen = -1
		end		
		local _kxSeries = SimCityPhai[tenPhai].knownIds[id].series
		if _kxSeries == 0 then realGen = -1 elseif _kxSeries == 2 then realGen = -2 end		
		if tenPhai == "thienvuong" or tenPhai == "thieulam" then realGen = -1 elseif tenPhai == "ngami" or tenPhai == "thuyyen" then realGen = -2 end
		
		self:taoNV(id, forCamp, pW, 1, 1, {}, 1, {
			szName = ten,
			nSettingsIdx = realGen,
			series = SimCityPhai[tenPhai].knownIds[id].series,
			faction = tenPhai
		})
	end

	
end

function SimCityKeoXe:mainMenu()
	local tbSay = createTaskSayKeoxe()
	tinsert(tbSay, "Thu� s�t th�/#SimCityTieuThiep:nhanTieuThiep(1)")
		
	--tinsert(tbSay, "Thi�t l�p/#SimCityKeoXe:caidat()")
	tinsert(tbSay, "Gi�i t�n/#SimCityKeoXe:RemoveAll()")
	tinsert(tbSay, "K�t th�c ��i tho�i./no")
	CreateTaskSay(tbSay)

	return 1
end

function SimCityKeoXe:RemoveAll()
	local name = GetName()

	if self.collections[name] then
		self.collections[name] = nil
	end
	for key, fighter in SimTheoSau.fighterList do
        local name = GetName()
        if fighter.playerID == name and fighter.mode == "keoxe" then
            SimTheoSau:Remove(fighter.id)
        end
    end
end



function SimCityKeoXe:ATick()
	-- Get info for npc in this world
	for name, children in self.collections do
		local parentID = SearchPlayer(name)

		if parentID > 0 then
			local pW, pX, pY = CallPlayerFunction(parentID, GetWorldPos)
			local newLoc = "" .. pW .. pY .. pX
			if not self.collections_knownPoint[name] or self.collections_knownPoint[name] ~= newLoc then
				self.collections_knownPoint[name] = newLoc
				local size = getn(children)
				local centerCharId = getCenteredCell(createFormation(size))
				local fighter = SimTheoSau:Get(children[centerCharId])
				local nX, nY, nMapIndex = GetNpcPos(fighter.finalIndex)
				local newPath = genCoords_squareshape({ nX / 32, nY / 32 }, { pX, pY }, size)
				for i = 1, size do
					SimTheoSau:Get(children[i]).parentAppointPos = newPath[i]
				end
			end
		end
	end

end 