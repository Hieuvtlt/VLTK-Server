
Include("\\script\\global\\nobitaxd\\vdk\\simcity\\main.lua")
Include("\\script\\misc\\eventsys\\eventsys.lua")

function add_npc_vinh()
end

function simcity_addNpcs()
	-- SimCity: them Trieu Man o 7 thanh
	--SimCityThanhThi:addNpcs()
	
	-- KeoXe: them VoKy o TuongDuong
	--add_dialognpc({ 
	--	{103,78,1619,3251,"\\script\\global\\nobitaxd\\vdk\\simcity\\controllers\\keoxe.lua","V� K�"}, 
	--	{103,53,1614,3210,"\\script\\global\\nobitaxd\\vdk\\simcity\\controllers\\keoxe.lua","V� K�"},
	--})

	-- VatNuoi: them VatNuoi o TuongDuong
	--SimCityVatNuoi:addNpcs()

	-- Event sys when user enter/leave map
	for id, map in SimCityMap do
		EventSys:GetType("EnterMap"):Reg(id, SimCityThanhThi.onPlayerEnterMap, SimCityThanhThi)
		EventSys:GetType("LeaveMap"):Reg(id, SimCityThanhThi.onPlayerExitMap, SimCityThanhThi)
		EventSys:GetType("EnterMap"):Reg(id, SimCityVatNuoi.onPlayerEnterMap, SimCityVatNuoi)		
	end
	

end

function simcity_clearTongKim()
	SimCityChienTranh:removeAll()
end